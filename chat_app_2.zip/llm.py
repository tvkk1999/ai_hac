from langchain_openai import ChatOpenAI 
import os 
import httpx 
from dotenv import load_dotenv

load_dotenv()

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model = "azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=os.getenv('OPENAI_API_KEY'),
    http_client = client
)