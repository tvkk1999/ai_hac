# router_option_a.py
import os
import json
from datetime import datetime
from typing import TypedDict, Annotated, Literal

import httpx
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain.tools import tool

from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolNode
import operator

# Optional: your Tavily search wrapper (same as you used)
from langchain_tavily import TavilySearch

# Load environment
load_dotenv(".env")

# HTTP client (disable verify if using internal certs)
client = httpx.Client(verify=False)

# LLM clients
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-Phi-4-reasoning",
    api_key=os.getenv("OPENAI_API_KEY"),  # type: ignore
    http_client=client,
)

llm2 = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-4o",
    api_key=os.getenv("OPENAI_API_KEY"),  # type: ignore
    http_client=client,
)


# Agent state typedict
class AgentState(TypedDict):
    question: str
    agent_type: str
    rag_result: dict
    final_answer: str

    messages: Annotated[list, operator.add]
    session_id: str
    timestamp: str
    step_count: int
    current_step: str
    errors: list
    metadata: dict
    conversation_history: list


# ----------------------------
# Tools: WebSearchTool & SummaryTool
# ----------------------------
@tool
def WebSearchTool(query: str) -> str:
    """Return search results (as a JSON string)."""
    tavily_search = TavilySearch(max_results=5)
    data = tavily_search.invoke({"query": query})
    # Return serializable JSON string (ToolNode will attach this to a ToolMessage)
    return json.dumps(data)


@tool
def SummaryTool(content: str) -> str:
    """This is used for generating Summary for the content"""
    prompt = f"Summarize the content in ~150 words, including major points:\n\n{content}"
    response = llm2.invoke(prompt)
    return response.content


TOOLS = [WebSearchTool, SummaryTool]


# ----------------------------
# Pre-screening
# ----------------------------
def pre_screen_question(state: AgentState):
    # ensure mutable copy
    state = dict(state)
    state["current_step"] = "pre_screening"
    state["step_count"] = state.get("step_count", 0) + 1
    question = state["question"]

    prompt = f"""Classify this input as exactly one word: "casual" or "task".
- "casual" = simple greetings/thanks only (e.g., Hi, Hello, Thanks)
- "task" = anything requiring information / web lookup

Input: {question}
Respond with only: casual or task
"""
    try:
        resp = llm.invoke(prompt).content.strip().lower()
        resp = "casual" if "casual" in resp else "task"
        state.setdefault("metadata", {})["pre_screen_category"] = resp

        if resp == "casual":
            state["agent_type"] = "direct"
            state.setdefault("messages", []).append(AIMessage(content="[pre-screen: casual]"))
        else:
            state["agent_type"] = "needs_agents"
            state.setdefault("messages", []).append(AIMessage(content="[pre-screen: task]"))
    except Exception as e:
        state.setdefault("errors", []).append(f"pre_screen_error: {e}")
        state["agent_type"] = "needs_agents"

    return state


# ----------------------------
# Direct response for greetings
# ----------------------------
def direct_llm_response(state: AgentState) -> AgentState:
    state = dict(state)
    state["current_step"] = "direct_response"
    state["step_count"] = state.get("step_count", 0) + 1
    question = state["question"]

    prompt = f"You are friendly. Briefly respond to this greeting (1 sentence).\nUser: {question}\nResponse:"
    try:
        response = llm2.invoke(prompt)
        state["final_answer"] = response.content
        state.setdefault("messages", []).append(AIMessage(content="[direct_response_provided]"))
    except Exception as e:
        state.setdefault("errors", []).append(f"direct_response_error: {e}")
        state["final_answer"] = "Hello! How can I help you today?"

    return state


# ----------------------------
# Web search agent (creates AIMessage with tool_calls in LangGraph-standard shape)
# ----------------------------
def web_search_agent(state: AgentState):
    state = dict(state)
    state["current_step"] = "web_agent"
    state["step_count"] = state.get("step_count", 0) + 1

    msgs = state.get("messages") or []
    last = msgs[-1] if msgs else None

    # If last is ToolMessage (tool executed), process its content and produce final answer
    if isinstance(last, ToolMessage):
        tool_output = last.content
        # tool_output is a string (we returned JSON string for WebSearchTool). Parse if needed.
        prompt = f"Use the tool output below to answer the user's question concisely.\n\nTool output:\n{tool_output}\n\nUser question: {state.get('question')}"
        try:
            response = llm2.invoke(prompt)
            state["final_answer"] = response.content
            state.setdefault("metadata", {})["tool_used"] = True
            return state
        except Exception as e:
            state.setdefault("errors", []).append(f"post_tool_llm_error: {e}")
            state["final_answer"] = "Sorry, I couldn't process the search results."
            return state

    # Otherwise: ask LLM to return a JSON tool call with keys: "tool" and "arguments"
    question = state["question"]
    planning_prompt = f"""You must reply with a JSON object (and ONLY the JSON) representing a tool call.
Example:
{{
  "tool": "WebSearchTool",
  "arguments": {{ "query": "latest finance news" }}
}}

User question: {question}
"""
    try:
        raw = llm2.invoke(planning_prompt).content.strip()
    except Exception as e:
        state.setdefault("errors", []).append(f"planning_llm_error: {e}")
        state["final_answer"] = "Planning error."
        return state

    # Heuristic: extract JSON substring (allows extra commentary)
    try:
        start = raw.find("{")
        end = raw.rfind("}")
        json_text = raw[start : end + 1] if start != -1 and end != -1 else raw
        tool_call = json.loads(json_text)
    except Exception as e:
        state.setdefault("errors", []).append(f"tool_call_parse_error: {e} | raw: {raw}")
        state["final_answer"] = "Tool call parse error."
        return state

    # Validate shape
    if not isinstance(tool_call, dict) or "tool" not in tool_call:
        state.setdefault("errors", []).append(f"invalid_tool_call_shape: {tool_call}")
        state["final_answer"] = "Invalid tool call shape."
        return state

    tool_name = tool_call["tool"]
    arguments = tool_call.get("arguments", {})

    # Create an AIMessage with tool_calls list (LangGraph / LangChain expected structure)
    ai_msg = AIMessage(
        content="",
        tool_calls=[
            {
                "id": "call_1",
                "name": tool_name,
                "args": arguments,
            }
        ],
    )

    # Append AIMessage so ToolNode can find it and execute
    state.setdefault("messages", []).append(ai_msg)
    return state


# ----------------------------
# Routing helper and workflow
# ----------------------------
def decide_route_type(state: AgentState) -> Literal["direct", "agents"]:
    """Route to DirectResponse if pre_screen set it, otherwise to agents."""
    return "direct" if state.get("agent_type") == "direct" else "agents"


def web_tools_condition(state: AgentState) -> str:
    """
    Return:
      - 'tools' if last message is AIMessage containing a tool_calls entry (ToolNode should run)
      - 'continue' if last message is ToolMessage (so agent will process tool output)
      - '__end__' if final_answer is present
      - 'continue' as default
    """
    if state.get("final_answer"):
        return "__end__"

    msgs = state.get("messages") or []
    if not msgs:
        return "continue"

    last = msgs[-1]
    # AIMessage with tool_calls -> run tools
    if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
        return "tools"
    # ToolMessage -> go back to agent to process
    if isinstance(last, ToolMessage):
        return "continue"

    return "continue"


def CreateWorkFlow():
    workflow = StateGraph(AgentState)

    workflow.add_node("pre_screen", pre_screen_question)
    workflow.add_node("DirectResponse", direct_llm_response)
    workflow.add_node("WebSearchAgent", web_search_agent)
    workflow.add_node("tools", ToolNode(TOOLS))

    workflow.set_entry_point("pre_screen")
    workflow.add_conditional_edges(
        "pre_screen",
        decide_route_type,
        {"direct": "DirectResponse", "agents": "WebSearchAgent"},
    )

    workflow.add_conditional_edges(
        "WebSearchAgent",
        web_tools_condition,
        {"tools": "tools", "__end__": END, "continue": "WebSearchAgent"},
    )

    # After ToolNode executes, route back to WebSearchAgent to process ToolMessage
    workflow.add_edge("tools", "WebSearchAgent")
    workflow.add_edge("DirectResponse", END)

    return workflow.compile()


Workflow = CreateWorkFlow()


# ----------------------------
# Runner
# ----------------------------
def Run(Question: str, ChatID: str):
    initial_state: AgentState = {
        "question": Question,
        "agent_type": "",
        "rag_result": {},
        "final_answer": "",
        # Start messages with a HumanMessage (ToolNode expects messages to be BaseMessage objects)
        "messages": [HumanMessage(content=Question)],
        "session_id": ChatID,
        "timestamp": datetime.now().isoformat(),
        "step_count": 0,
        "current_step": "initialized",
        "errors": [],
        "metadata": {},
        "conversation_history": [],
    }

    final_state = Workflow.invoke(initial_state)

    return {
        "question": Question,
        "agent_type": final_state.get("agent_type"),
        "final_answer": final_state.get("final_answer"),
        "messages": final_state.get("messages"),
        "errors": final_state.get("errors"),
        "success": len(final_state.get("errors", [])) == 0,
    }


if __name__ == "__main__":
    print(Run("Give me news related latest finance updates", "001"))