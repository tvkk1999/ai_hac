document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("msgForm");
  const input = document.getElementById("msgInput");
  const messagesDiv = document.getElementById("messages");
  const status = document.getElementById("status");
  const chatId = messagesDiv.dataset.chatId;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;

    // disable UI while waiting
    input.disabled = true;
    status.textContent = "Waiting for response...";
    const formData = new FormData();
    formData.append("message", text);

    try {
      const resp = await fetch(`/chat/${chatId}/message`, {
        method: "POST",
        body: formData
      });

      if (!resp.ok) throw new Error(`Server error: ${resp.status}`);

      const payload = await resp.json();

      // OPTION B (server returned HTML snippet)
      if (payload.html) {
        // append the new messages snippet to messages container
        const tmp = document.createElement("div");
        tmp.innerHTML = payload.html;
        // append children (avoids replacing entire container)
        while (tmp.firstChild) {
          messagesDiv.appendChild(tmp.firstChild);
        }
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      } else if (payload.reply) {
        // OPTION A (server returned structured JSON)
        // build DOM nodes client side
        const userMsg = document.createElement("div");
        userMsg.className = "message user";
        userMsg.innerHTML = `<div class="text">${escapeHtml(text)}</div>`;
        messagesDiv.appendChild(userMsg);

        const botMsg = document.createElement("div");
        botMsg.className = "message bot";
        botMsg.innerHTML = `<div class="text">${escapeHtml(payload.reply)}</div>`;
        messagesDiv.appendChild(botMsg);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      }

      input.value = "";
    } catch (err) {
      console.error(err);
      status.textContent = "Error sending message";
    } finally {
      input.disabled = false;
      status.textContent = "";
      input.focus();
    }
  });

  // utility
  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, s => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    })[s]);
  }
});

async function createNewChat() {
  const resp = await fetch('/chats/new', { method: 'POST' });
  const { chat_id, url } = await resp.json();
  // change URL shown in address bar without reload
  history.pushState({chat_id}, '', url);

  // optionally replace messages container and dataset
  document.getElementById('messages').innerHTML = ''; 
  document.getElementById('messages').dataset.chatId = chat_id;
}