const sidebar = document.getElementById("sidebar");
const toggleSidebar = document.getElementById("toggleSidebar");
const messages = document.getElementById("messages");
const input = document.getElementById("input");
const sendBtn = document.getElementById("sendBtn");
const attachBtn = document.getElementById("attachBtn");
const fileInput = document.getElementById("fileInput");
const popupBtn = document.getElementById("popupBtn");
const popup = document.getElementById("popup");
const popupAdd = document.getElementById("popupAdd");
const popupCancel = document.getElementById("popupCancel");
const popupUrl = document.getElementById("popupUrl");
const popupText = document.getElementById("popupText");
const status1 = document.getElementById("status1");
const chatId = messages.dataset.chatId;

toggleSidebar.addEventListener("click", () => {
  // Toggle collapsed state on the sidebar element
  sidebar.classList.toggle("collapsed");
  // Also toggle a class on the root .app so the grid updates and the main area expands
  document.querySelector(".app").classList.toggle("sidebar-collapsed");
});

sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// attachBtn.addEventListener("click", () => fileInput.click());
// fileInput.addEventListener("change", (e) => {
//   const file = e.target.files[0];
//   print(file)
//   if (!file) return;
//   appendMessage(`📎 Attached: ${file.name}`, "user");
//   // reset
//   fileInput.value = "";
// });

const attachedFiles = [];

attachBtn.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", async (e) => {
  const files = Array.from(e.target.files);

  files.forEach((file) => {
    attachedFiles.push({
      name: file.name,
      size: file.size,
      type: file.type,
      relativePath: file.webkitRelativePath, // 👈 important
      file,                                  // actual File object
    });

    // You can show just the top folder or each file
      appendMessage(`📁 Added from folder: ${file.webkitRelativePath}`, "user");
      console.log(attachedFiles);
      console.log(`-----@@@@---------${files}`)
    });
    console.log(`--------------${files}`)
  // const files = fileInput.files;
  // if (!files || files.length === 0) {
  //   alert("Please select at least one file");
  //   return;
  // }

  const formData = new FormData();

  // // 👇 Append all files under the same key name: "files"
  Array.from(files).forEach((file) => {
    formData.append("files", file); // backend key = "files"
  });

  try {
    const res = await fetch(`/upload?chat_id=${chatId}`, {
      method: "POST",
      body: formData,   // ❗ Don't set Content-Type, browser sets it
    });

    const data = await res.json();
    console.log("Upload response:", data);
  } catch (err) {
    console.error("Upload failed:", err);
  }
});

popupBtn.addEventListener("click", () => {
  popup.classList.toggle("open");
  if (popup.classList.contains("open")) {
    // position popup relative to input area (simple)
    // focus url
    popupUrl.focus();
  }
});

popupCancel.addEventListener("click", () => {
  popup.classList.remove("open");
  popupUrl.value = "";
  popupText.value = "";
});

popupAdd.addEventListener("click", () => {
  const url = popupUrl.value.trim();
  const txt = popupText.value.trim();
  if (url) appendMessage(`🔗 Link: ${url}\n${txt ? "\n" + txt : ""}`, "user");
  else if (txt) appendMessage(txt, "user");
  popup.classList.remove("open");
  popupUrl.value = "";
  popupText.value = "";
});

function appendMessage(text, who = "user") {
  const el = document.createElement("div");
  el.className = "msg " + (who === "user" ? "user" : "bot");
  // preserve line breaks
  el.innerHTML = text.replace(/\n/g, "<br>");
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}

async function sendMessage() {
  console.log("Hi")
  const text = input.value.trim();
  if (!text) return;
  // disable UI while waiting
  input.disabled = true;
  const formData = new FormData();
  formData.append("message", text);

  try {
    const resp = await fetch(`/chat/${chatId}/message?role=user`, {
      method: "POST",
      body: formData
    });

    if (!resp.ok) throw new Error(`Server error: ${resp.status}`);

    const payload = await resp.json();

    // OPTION B (server returned HTML snippet)
    // append the new messages snippet to messages container
    const tmp = document.createElement("div");
    tmp.innerHTML = payload.html;
    // append children (avoids replacing entire container)
    while (tmp.firstChild) {
      messages.appendChild(tmp.firstChild);
    }
    messages.scrollTop = messages.scrollHeight;
    input.value = "";
  } catch (err) {
    console.error(err);
    status1.textContent = "Error sending message";
  } finally {
    input.disabled = false;
    status1.textContent = "";
    input.focus();
  }

  status1.textContent = "Waiting for response...";
  
  try {
    const resp = await fetch(`/chat/${chatId}/message?role=ai`, {
      method: "POST",
      body: formData
    });

    if (!resp.ok) throw new Error(`Server error: ${resp.status}`);

    const payload = await resp.json();

    // OPTION B (server returned HTML snippet)
    // append the new messages snippet to messages container
    const tmp = document.createElement("div");
    tmp.innerHTML = payload.html;
    // append children (avoids replacing entire container)
    while (tmp.firstChild) {
      messages.appendChild(tmp.firstChild);
    }
    messages.scrollTop = messages.scrollHeight;
    input.value = "";
  } catch (err) {
    console.error(err);
    status1.textContent = "Error sending message";
  } finally {
    input.disabled = false;
    status1.textContent = "";
    input.focus();
  }
}

function escapeHtml(unsafe) {
  return unsafe.replace(/[&<>\"']/g, function (m) {
    return {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;",
    }[m];
  });
}

// async function createNewChat() {
//   const resp = await fetch('/chats/new', { method: 'POST' });
//   const { chat_id, url } = await resp.json();
//   // change URL shown in address bar without reload
//   history.pushState({chat_id}, '', url);

//   // optionally replace messages container and dataset
//   document.getElementById('messages').innerHTML = ''; 
//   document.getElementById('messages').dataset.chatId = chat_id;
// }

// small autosize for textarea
const ta = input;
function autosize() {
  ta.style.height = "auto";
  ta.style.height = ta.scrollHeight + "px";
}
ta.addEventListener("input", autosize);
autosize();

// const evtSource = new EventSource("/stream");
// evtSource.onmessage = (event) => {
//   messages.insertAdjacentHTML("beforeend", event.data);
// };