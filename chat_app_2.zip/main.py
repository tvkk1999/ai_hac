from itertools import chain
import os
from typing import List
from fastapi import FastAPI, File, HTTPException, Request, Form, UploadFile
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uuid
import time
import httpx
from starlette.exceptions import HTTPException as StarletteHTTPException
from markdown import markdown
import asyncio

from llm import llm
from news_digest.main import Run

app = FastAPI()
templates = Jinja2Templates(directory="templates")
templates.env.filters["markdown"] = lambda text: markdown(text)

# static files (css/js)
app.mount("/static", StaticFiles(directory="static"), name="static")

# in-memory store for demo (use DB in real app)
CHATS = {}  # chat_id -> {messages: [{role, text, ts}], modified_at}
username = "string1"

# Utils
def get_chats_list():
    url = f"http://127.0.0.1:8000/users/{username}/chats"
    response = httpx.get(url)
    data = response.json()
    print(data)
    print("-"*100)
    print(data[0].keys())
    chat_list = [{"chat_id": c.get("id", ""), "title": c.get("title", "")} for c in data]
    print(chat_list)
    return chat_list

def get_messages_list(chat_id):
    url = f"http://127.0.0.1:8000/chats/{chat_id}/messages"
    response = httpx.get(url)
    data = response.json()
    print(data)
    msg_list = [{"message_id": m.get("id", ""), "role":m.get("role", ""), "content":m.get("content", "")} for m in data]
    print(msg_list)
    return msg_list

def check_chat_id(chat_id):
    chat_list = get_chats_list()

    for c in chat_list:
        print(c)
        if chat_id == c["chat_id"]:
            return True
    
    return False

# Routes

@app.get("/")
def home():
    url = "http://127.0.0.1:8000/chats"
    payload = {
        "username": username,
        "title": "New Chat"
    }
    response = httpx.post(url, json=payload)
    data = response.json()
    print(data)
    chat_id = data["id"]
    return RedirectResponse(url=f"/chat/{chat_id}")


@app.get("/chat/{chat_id}", response_class=HTMLResponse)
def get_chat(request: Request, chat_id: str):
    if check_chat_id(chat_id):
        chat_list = get_chats_list()
        rendered_chat_list = templates.get_template("partials/chats_list_snippet.html").render({"chat_list": chat_list, "current_chat_id": chat_id})
        print(rendered_chat_list)
        
        msg_list = get_messages_list(chat_id)
        print("*"*50)
        print(msg_list)
        rendered_msg_list = ""
        if msg_list and len(msg_list) != 0:
            rendered_msg_list = templates.get_template("partials/messages_snippet1.html").render({"messages": msg_list})
            print(rendered_msg_list)
        
        return templates.TemplateResponse("chat.html", {"request": request, "chat_id": chat_id, "chats_list_rendered": rendered_chat_list, "rendered_msg_list": rendered_msg_list})
    raise HTTPException(404, "Not found")

@app.post("/chat/{chat_id}/message")
async def post_message(request: Request, chat_id: str, role: str, message: str = Form(...)):
    if check_chat_id(chat_id):
        if role == "user":
            # Store user message
            url = "http://127.0.0.1:8000/messages"
            payload = {
                "chat_id": chat_id,
                "role": "user",
                "content": message
            }
            response = httpx.post(url, json=payload)
            user_msg = response.json()
            print(user_msg)
            
            msg_list = [user_msg]
        
        if role == "ai":
            # simulate LLM processing (replace with real call)
            # llm_reply = llm.invoke(message).content
            llm_reply = Run(message, chat_id).get("final_answer", "")

            # store bot reply
            url = "http://127.0.0.1:8000/messages"
            payload = {
                "chat_id": chat_id,
                "role": "ai",
                "content": llm_reply
            }
            response = httpx.post(url, json=payload)
            ai_msg = response.json()
            print(ai_msg)
            
            # OPTION A: return JSON (structured) and let client render
            # return JSONResponse({"status":"ok","reply":llm_reply, "user_message": message})

            # OPTION B: render a small HTML snippet server-side and return it (client injects into DOM)
            msg_list = [ai_msg]
        
        rendered = templates.get_template("partials/messages_snippet1.html").render({"messages": msg_list})
        print(role, ":", rendered)
        
        return JSONResponse({"status":"ok", "html": rendered})
    
    raise HTTPException(404, "Not found")

# def sse_format(data: str) -> str:
#     return f"data: {data}\n\n"

# async def event_stream(request: Request):
#     # Get a Jinja partial template for one message
#     tmpl = templates.get_template("partials/message.html")

#     for i in range(5):
#         # Stop if client disconnected
#         if await request.is_disconnected():
#             break

#         html_chunk = tmpl.render(message=f"Chunk {i}")
#         yield sse_format(html_chunk)
#         await asyncio.sleep(1)

# @app.get("/stream")
# async def stream(request: Request):
#     return StreamingResponse(
#         event_stream(request),
#         media_type="text/event-stream"
#     )

@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 404:
        return JSONResponse(
            status_code=404,
            content={"message": "Route not found"}
        )
    return JSONResponse(
        status_code=exc.status_code,
        content={"message": exc.detail}
    )

@app.post("/upload")
async def upload_files(chat_id: str, files: List[UploadFile] = File(...)):
    UPLOAD_DIR = f"uploads/{chat_id}"
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    
    saved_files = []

    for file in files:
        file_location = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_location, "wb") as f:
            f.write(await file.read())
        saved_files.append({
            "name": file.filename,
            "path": file_location,
            "content_type": file.content_type
        })

    return {"files": saved_files}