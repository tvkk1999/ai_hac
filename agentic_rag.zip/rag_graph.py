# rag_graph.py
from __future__ import annotations
from typing import TypedDict, List, Optional
from pathlib import Path
import textwrap
import requests
from bs4 import BeautifulSoup

from langgraph.graph import StateGraph, END

from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings

from langchain_community.vectorstores import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

# ---- LLM + Embeddings ----

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-pro",  # or any chat model you have
    temperature=0,
)

embeddings = GoogleGenerativeAIEmbeddings(
    model="models/gemini-embedding-001"  # or any embedding model you use
)

# ---- Chroma VectorStore (backed by chromadb) ----

VECTOR_DB_DIR = "./chroma_rag_db"

vectordb = Chroma(
    collection_name="rag_collection",
    embedding_function=embeddings,
    persist_directory=VECTOR_DB_DIR,
)

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
)


# ---- Graph State ----

class RAGState(TypedDict, total=False):
    question: str
    url: Optional[str]
    file_path: Optional[str]

    # internal
    doc_ids: List[str]
    retrieved_docs: List[Document]
    answer: str


# ---- Helper: load content ----

def _load_from_url(url: str) -> str:
    resp = requests.get(url, timeout=15)
    resp.raise_for_status()
    html = resp.text
    soup = BeautifulSoup(html, "html.parser")
    # simple heuristic: get visible text
    text = soup.get_text(separator="\n")
    return text


def _load_from_file(path_str: str) -> str:
    path = Path(path_str)
    if not path.exists():
        raise FileNotFoundError(path)

    # Very simple: assume text file.
    # For PDFs / docs: plug in a proper loader (PyPDFLoader, etc.)
    return path.read_text(encoding="utf-8", errors="ignore")


# ---- Node 1: ingest (file or URL) into Chroma ----

def ingest(state: RAGState) -> RAGState:
    source_text: str

    if state.get("url"):
        source_text = _load_from_url(state["url"])
        source_meta = {"source_type": "url", "source": state["url"]}
    elif state.get("file_path"):
        source_text = _load_from_file(state["file_path"])
        source_meta = {"source_type": "file", "source": state["file_path"]}
    else:
        # No new corpus; rely on whatever is already in Chroma
        return state

    chunks = text_splitter.split_text(source_text)
    docs = [Document(page_content=c, metadata=source_meta) for c in chunks]

    ids = vectordb.add_documents(docs)
    vectordb.persist()

    return {
        **state,
        "doc_ids": ids,
    }


# ---- Node 2: multi-query retrieval ----

def retrieve(state: RAGState) -> RAGState:
    question = state["question"]

    retriever = vectordb.as_retriever(
        search_kwargs={"k": 6}   # top-k retrieved chunks
    )

    docs = retriever.invoke(question)

    return {
        **state,
        "retrieved_docs": docs,
    }


# ---- Node 3: answer with LLM ----

def answer(state: RAGState) -> RAGState:
    docs = state.get("retrieved_docs") or []
    context = "\n\n".join(
        f"[Doc {i+1}]\n{d.page_content}"
        for i, d in enumerate(docs)
    )

    prompt = textwrap.dedent(f"""
    You are a helpful assistant doing RAG.

    Use ONLY the context below to answer the question.
    If the answer is not in the context, say you don't know.

    # Context
    {context}

    # Question
    {state["question"]}

    # Answer (include citations like [Doc 1], [Doc 2] where relevant):
    """).strip()

    resp = llm.invoke(prompt)
    return {
        **state,
        "answer": resp.content,
    }


# ---- Build the graph ----

def build_graph():
    graph = StateGraph(RAGState)

    graph.add_node("ingest", ingest)
    graph.add_node("retrieve", retrieve)
    graph.add_node("answer", answer)

    graph.set_entry_point("ingest")
    graph.add_edge("ingest", "retrieve")
    graph.add_edge("retrieve", "answer")
    graph.add_edge("answer", END)

    return graph.compile()


# This variable name is what langgraph.json will point to
graph = build_graph()
