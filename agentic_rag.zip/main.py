def main():
    print("Hello from agentic-multiquery-rag!")


if __name__ == "__main__":
    main()
