# client.py
import asyncio
from langgraph_sdk import get_client

async def run_query(question: str, url: str | None = None, file_path: str | None = None):
    client = get_client()  # default: http://localhost:8123

    # Find our assistant corresponding to graph "rag-agent"
    assistants = await client.assistants.search()
    # You can filter by name if you have many
    rag_assistant = next(a for a in assistants if a["name"] == "rag-agent")

    # Threadless run (or you can create a thread if you want stateful convos)
    input_payload = {
        "question": question,
        "url": url,
        "file_path": file_path,
    }

    print("=== Streaming response ===")
    async for chunk in client.runs.stream(
        None,  # thread_id (None = threadless run)
        rag_assistant["assistant_id"],
        input=input_payload,
    ):
        # You can inspect chunk.event / chunk.data
        if chunk.event == "end":
            # Final state
            final_state = chunk.data.get("state", {})
            print("\n\n=== Final Answer ===")
            print(final_state.get("answer"))
    print("=== Done ===")


if __name__ == "__main__":
    # EXAMPLE 1: URL-based RAG
    asyncio.run(
        run_query(
            question="Summarise the main points of this page.",
            url="https://docs.langchain.com/oss/javascript/langchain/retrieval",
        )
    )

    # EXAMPLE 2: File-based RAG
    # asyncio.run(
    #     run_query(
    #         question="What are the key ideas in this document?",
    #         file_path="data/my_notes.txt",
    #     )
    # )
