import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import random
from config import EQUIPMENT_CATEGORIES, MAINTENANCE_TYPES

class SyntheticDataGenerator:
    """Generate realistic synthetic data for EV manufacturing equipment maintenance"""
    
    def __init__(self, seed=42):
        random.seed(seed)
        np.random.seed(seed)
        self.start_date = datetime.now() - timedelta(days=365)
        
    def generate_machine_usage_logs(self, num_days=365):
        """Generate machine usage logs with realistic patterns"""
        data = []
        equipment_list = []
        
        for category, machines in EQUIPMENT_CATEGORIES.items():
            for machine in machines:
                equipment_list.append({
                    "equipment_id": f"{category[:3].upper()}-{machines.index(machine)+1:03d}",
                    "equipment_name": machine,
                    "category": category
                })
        
        for day in range(num_days):
            current_date = self.start_date + timedelta(days=day)
            
            for equip in equipment_list:
                # Simulate daily usage with some variation
                if random.random() > 0.05:  # 95% uptime normally
                    runtime_hours = random.uniform(18, 23)  # Most machines run near 24/7
                    cycles = int(runtime_hours * random.uniform(20, 50))
                    
                    # Add wear patterns
                    age_factor = day / num_days
                    vibration = random.uniform(0.1, 0.5) + age_factor * 0.3
                    temperature = random.uniform(45, 75) + age_factor * 10
                    power_consumption = random.uniform(80, 150) + cycles * 0.01
                    
                    data.append({
                        "date": current_date.strftime("%Y-%m-%d"),
                        "equipment_id": equip["equipment_id"],
                        "equipment_name": equip["equipment_name"],
                        "category": equip["category"],
                        "runtime_hours": round(runtime_hours, 2),
                        "production_cycles": cycles,
                        "vibration_level": round(vibration, 3),
                        "temperature_avg": round(temperature, 2),
                        "power_consumption_kwh": round(power_consumption, 2),
                        "error_codes": random.randint(0, 5) if random.random() > 0.8 else 0
                    })
        
        return pd.DataFrame(data)
    
    def generate_maintenance_records(self, num_records=500):
        """Generate historical maintenance records"""
        data = []
        equipment_list = []
        
        for category, machines in EQUIPMENT_CATEGORIES.items():
            for machine in machines:
                equipment_list.append({
                    "equipment_id": f"{category[:3].upper()}-{machines.index(machine)+1:03d}",
                    "equipment_name": machine,
                    "category": category
                })
        
        technicians = [
            "Sai Narasimha", "Manikiran", "Krishna", "Yeshwanth Akhil",
            "Ranganadha Gupta", "Lisa Anderson", "Robert Taylor", "Anna Rodriguez"
        ]
        
        for i in range(num_records):
            equip = random.choice(equipment_list)
            maint_date = self.start_date + timedelta(days=random.randint(0, 365))
            maint_type = random.choice(MAINTENANCE_TYPES)
            
            # Duration depends on type
            duration_map = {
                "Preventive Inspection": (1, 3),
                "Lubrication Service": (0.5, 1.5),
                "Calibration": (2, 4),
                "Component Replacement": (3, 8),
                "Software Update": (1, 2),
                "Deep Cleaning": (2, 4),
                "Performance Testing": (1, 3),
                "Safety Check": (1, 2),
                "Electrical Inspection": (2, 5),
                "Hydraulic System Service": (3, 6)
            }
            
            duration = random.uniform(*duration_map[maint_type])
            cost = duration * random.uniform(150, 300)
            
            data.append({
                "maintenance_id": f"MNT-{i+1:05d}",
                "date": maint_date.strftime("%Y-%m-%d"),
                "equipment_id": equip["equipment_id"],
                "equipment_name": equip["equipment_name"],
                "category": equip["category"],
                "maintenance_type": maint_type,
                "duration_hours": round(duration, 2),
                "technician": random.choice(technicians),
                "parts_replaced": random.choice([None, "Bearings", "Seals", "Filters", "Sensors", "Belts", "Motors"]),
                "cost_usd": round(cost, 2),
                "status": random.choice(["Completed", "Completed", "Completed", "Delayed"]),
                "notes": random.choice([
                    "Routine maintenance completed",
                    "Minor adjustments made",
                    "Replaced worn components",
                    "Calibration within spec",
                    "Software updated successfully"
                ])
            })
        
        return pd.DataFrame(data)
    
    def generate_failure_incidents(self, num_incidents=150):
        """Generate failure incident reports"""
        data = []
        equipment_list = []
        
        for category, machines in EQUIPMENT_CATEGORIES.items():
            for machine in machines:
                equipment_list.append({
                    "equipment_id": f"{category[:3].upper()}-{machines.index(machine)+1:03d}",
                    "equipment_name": machine,
                    "category": category
                })
        
        failure_types = [
            "Mechanical Failure", "Electrical Fault", "Software Crash",
            "Hydraulic Leak", "Overheating", "Sensor Malfunction",
            "Calibration Drift", "Belt/Chain Breakage", "Motor Failure",
            "Communication Error"
        ]
        
        root_causes = [
            "Normal wear and tear", "Improper lubrication", "Age-related degradation",
            "Overload condition", "Power surge", "Software bug",
            "Contamination", "Improper calibration", "Design limitation",
            "External factor"
        ]
        
        for i in range(num_incidents):
            equip = random.choice(equipment_list)
            incident_date = self.start_date + timedelta(days=random.randint(0, 365))
            
            downtime = random.uniform(0.5, 48)  # Hours
            severity = random.choice(["Low", "Medium", "High", "Critical"])
            
            data.append({
                "incident_id": f"INC-{i+1:05d}",
                "date": incident_date.strftime("%Y-%m-%d"),
                "time": f"{random.randint(0, 23):02d}:{random.randint(0, 59):02d}",
                "equipment_id": equip["equipment_id"],
                "equipment_name": equip["equipment_name"],
                "category": equip["category"],
                "failure_type": random.choice(failure_types),
                "severity": severity,
                "downtime_hours": round(downtime, 2),
                "production_loss_units": int(downtime * random.uniform(50, 200)),
                "root_cause": random.choice(root_causes),
                "corrective_action": random.choice([
                    "Component replaced", "System reset", "Recalibrated",
                    "Software patch applied", "Cleaned and serviced",
                    "Temporary fix - monitoring"
                ]),
                "prevented_by_maintenance": random.choice([True, False, False])
            })
        
        return pd.DataFrame(data)
    
    def generate_production_schedule(self, num_weeks=12):
        """Generate production schedule"""
        data = []
        start_date = datetime.now()
        
        production_models = [
            "EV Sedan Model A", "EV SUV Model B", "EV Compact Model C",
            "EV Truck Model D", "EV Sports Model E"
        ]
        
        for week in range(num_weeks):
            week_start = start_date + timedelta(weeks=week)
            
            for day in range(7):
                current_date = week_start + timedelta(days=day)
                
                # Weekend reduced production
                if day >= 5:
                    daily_target = random.randint(50, 100)
                else:
                    daily_target = random.randint(150, 250)
                
                data.append({
                    "date": current_date.strftime("%Y-%m-%d"),
                    "day_of_week": current_date.strftime("%A"),
                    "shift_1_target": int(daily_target * 0.35),
                    "shift_2_target": int(daily_target * 0.40),
                    "shift_3_target": int(daily_target * 0.25),
                    "total_daily_target": daily_target,
                    "primary_model": random.choice(production_models),
                    "production_priority": random.choice(["Normal", "High", "Rush Order"]),
                    "planned_maintenance_window": "22:00-06:00" if day in [2, 4] else None
                })
        
        return pd.DataFrame(data)
    
    def generate_resource_availability(self):
        """Generate maintenance resource and skill matrix"""
        technicians = [
            {"name": "Sai Narasimha", "level": "Senior", "specialties": ["Mechanical", "Hydraulic"]},
            {"name": "Manikiran", "level": "Expert", "specialties": ["Electrical", "Software"]},
            {"name": "Krishna", "level": "Senior", "specialties": ["Mechanical", "Calibration"]},
            {"name": "Yeshwanth Akhil", "level": "Mid-Level", "specialties": ["Electrical", "Safety"]},
            {"name": "Ranganadha Gupta", "level": "Expert", "specialties": ["Software", "Calibration"]},
            {"name": "Lisa Anderson", "level": "Senior", "specialties": ["Mechanical", "Hydraulic"]},
            {"name": "Robert Taylor", "level": "Mid-Level", "specialties": ["Electrical", "General"]},
            {"name": "Anna Rodriguez", "level": "Senior", "specialties": ["Mechanical", "Electrical"]}
        ]
        
        data = []
        for tech in technicians:
            for specialty in tech["specialties"]:
                data.append({
                    "technician_name": tech["name"],
                    "skill_level": tech["level"],
                    "specialty": specialty,
                    "hourly_rate": random.randint(40, 100) if tech["level"] == "Expert" else random.randint(30, 70),
                    "max_hours_per_week": 40,
                    "available_shifts": random.choice(["All", "Day/Evening", "Evening/Night"])
                })
        
        return pd.DataFrame(data)
    
    def save_all_data(self, output_dir="data"):
        """Generate and save all synthetic datasets"""
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        print("Generating machine usage logs...")
        usage_logs = self.generate_machine_usage_logs()
        usage_logs.to_csv(f"{output_dir}/machine_usage_logs.csv", index=False)
        
        print("Generating maintenance records...")
        maintenance = self.generate_maintenance_records()
        maintenance.to_csv(f"{output_dir}/maintenance_records.csv", index=False)
        
        print("Generating failure incidents...")
        failures = self.generate_failure_incidents()
        failures.to_csv(f"{output_dir}/failure_incidents.csv", index=False)
        
        print("Generating production schedule...")
        production = self.generate_production_schedule()
        production.to_csv(f"{output_dir}/production_schedule.csv", index=False)
        
        print("Generating resource availability...")
        resources = self.generate_resource_availability()
        resources.to_csv(f"{output_dir}/resource_availability.csv", index=False)
        
        print(f"\nAll data generated successfully in '{output_dir}/' directory!")
        print(f"- Machine usage logs: {len(usage_logs)} records")
        print(f"- Maintenance records: {len(maintenance)} records")
        print(f"- Failure incidents: {len(failures)} records")
        print(f"- Production schedule: {len(production)} days")
        print(f"- Resource availability: {len(resources)} skill entries")
        
        return {
            "usage_logs": usage_logs,
            "maintenance": maintenance,
            "failures": failures,
            "production": production,
            "resources": resources
        }

if __name__ == "__main__":
    generator = SyntheticDataGenerator()
    generator.save_all_data()
