import os
from dotenv import load_dotenv

load_dotenv()

# Azure Configuration
AZURE_API_KEY = os.getenv("AZURE_API_KEY", "")
AZURE_API_BASE = os.getenv("AZURE_API_BASE", "")
AZURE_API_VERSION = os.getenv("AZURE_API_VERSION", "2024-02-15-preview")

# Model Selection
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "azure/genailab-maas-text-embedding-3-large")
LLM_MODEL = os.getenv("LLM_MODEL", "azure/genailab-maas-gpt-4o")

# EV Manufacturing Equipment Categories
EQUIPMENT_CATEGORIES = {
    "battery_assembly": ["Battery Cell Stacker", "Electrode Coating Machine", "Battery Pack Assembly Line", "Cell Testing Chamber"],
    "motor_production": ["Stator Winding Machine", "Rotor Assembly System", "Motor Testing Rig", "Magnet Insertion Robot"],
    "chassis_welding": ["Robotic Welder Station 1-5", "Spot Welding Robot", "Frame Assembly Jig", "Welding Quality Scanner"],
    "paint_coating": ["Automated Paint Booth", "Powder Coating Line", "Drying Oven", "Surface Treatment Tank"],
    "final_assembly": ["Main Assembly Line Conveyor", "Torque Tool Station", "Wire Harness Robot", "Quality Inspection System"]
}

# Maintenance Task Types
MAINTENANCE_TYPES = [
    "Preventive Inspection",
    "Lubrication Service",
    "Calibration",
    "Component Replacement",
    "Software Update",
    "Deep Cleaning",
    "Performance Testing",
    "Safety Check",
    "Electrical Inspection",
    "Hydraulic System Service"
]

# Production Shift Configuration
SHIFTS = {
    "day_shift": {"start": "06:00", "end": "14:00"},
    "evening_shift": {"start": "14:00", "end": "22:00"},
    "night_shift": {"start": "22:00", "end": "06:00"}
}
