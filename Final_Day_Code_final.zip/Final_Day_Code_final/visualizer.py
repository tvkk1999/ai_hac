import pandas as pd
import plotly.figure_factory as ff
import plotly.graph_objects as go
from datetime import datetime, timedelta
from typing import List, Dict, Any
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from fpdf import FPDF
import json

class ScheduleVisualizer:
    """Create visualizations and export schedules"""
    
    def __init__(self):
        self.color_map = {
            "Critical": "#d32f2f",
            "High": "#f57c00",
            "Medium": "#fbc02d",
            "Low": "#388e3c",
            "Unknown": "#757575"
        }
    
    def create_gantt_chart(self, schedule_data: List[Dict[str, Any]]) -> go.Figure:
        """Create interactive Gantt chart for maintenance schedule"""
        
        if not schedule_data:
            # Return empty figure
            fig = go.Figure()
            fig.add_annotation(
                text="No maintenance tasks scheduled",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=20)
            )
            return fig
        
        # Prepare data for Gantt chart
        df_schedule = pd.DataFrame(schedule_data)
        df_schedule['Start'] = pd.to_datetime(df_schedule['scheduled_date'] + ' ' + df_schedule['scheduled_time'])
        df_schedule['Finish'] = df_schedule['Start'] + pd.to_timedelta(df_schedule['estimated_duration_hours'], unit='h')
        df_schedule['Resource'] = df_schedule['assigned_technician']
        
        # Create tasks list for Plotly
        tasks = []
        for _, row in df_schedule.iterrows():
            tasks.append(dict(
                Task=f"{row['equipment_name'][:30]}",
                Start=row['Start'],
                Finish=row['Finish'],
                Resource=row['Resource'],
                Description=f"{row['maintenance_type']} - {row['equipment_id']}",
                Priority=row.get('priority', 'Medium')
            ))
        
        # Sort by start date
        tasks.sort(key=lambda x: x['Start'])
        
        # Create Gantt chart
        fig = ff.create_gantt(
            tasks,
            colors=self.color_map,
            index_col='Priority',
            show_colorbar=True,
            group_tasks=True,
            showgrid_x=True,
            showgrid_y=True,
            title="Maintenance Schedule - Gantt Chart"
        )
        
        # Update layout
        fig.update_layout(
            height=max(400, len(tasks) * 25),
            xaxis_title="Date/Time",
            yaxis_title="Equipment",
            hovermode='closest',
            font=dict(size=10)
        )
        
        return fig
    
    def create_calendar_view(self, schedule_data: List[Dict[str, Any]]) -> go.Figure:
        """Create calendar heatmap view of maintenance activities"""
        
        if not schedule_data:
            fig = go.Figure()
            fig.add_annotation(
                text="No maintenance tasks scheduled",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False,
                font=dict(size=20)
            )
            return fig
        
        df_schedule = pd.DataFrame(schedule_data)
        df_schedule['scheduled_date'] = pd.to_datetime(df_schedule['scheduled_date'])
        
        # Count tasks per day
        daily_counts = df_schedule.groupby('scheduled_date').size().reset_index(name='task_count')
        
        # Create date range
        date_range = pd.date_range(
            start=daily_counts['scheduled_date'].min(),
            end=daily_counts['scheduled_date'].max()
        )
        
        # Create full date DataFrame
        df_dates = pd.DataFrame({'scheduled_date': date_range})
        df_dates = df_dates.merge(daily_counts, on='scheduled_date', how='left').fillna(0)
        
        # Add day of week and week number
        df_dates['day_of_week'] = df_dates['scheduled_date'].dt.day_name()
        df_dates['week'] = df_dates['scheduled_date'].dt.isocalendar().week
        df_dates['day_num'] = df_dates['scheduled_date'].dt.dayofweek
        
        # Pivot for heatmap
        pivot_data = df_dates.pivot_table(
            index='week',
            columns='day_num',
            values='task_count',
            fill_value=0
        )
        
        # Create heatmap
        fig = go.Figure(data=go.Heatmap(
            z=pivot_data.values,
            x=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            y=[f"Week {w}" for w in pivot_data.index],
            colorscale='RdYlGn_r',
            text=pivot_data.values,
            texttemplate='%{text}',
            textfont={"size": 12},
            colorbar=dict(title="Tasks per Day")
        ))
        
        fig.update_layout(
            title="Maintenance Schedule - Calendar View",
            xaxis_title="Day of Week",
            yaxis_title="Week",
            height=400
        )
        
        return fig
    
    def create_resource_utilization_chart(self, schedule_data: List[Dict[str, Any]]) -> go.Figure:
        """Create chart showing technician utilization"""
        
        if not schedule_data:
            fig = go.Figure()
            fig.add_annotation(
                text="No resource data available",
                xref="paper", yref="paper",
                x=0.5, y=0.5, showarrow=False
            )
            return fig
        
        df_schedule = pd.DataFrame(schedule_data)
        
        # Calculate hours per technician
        tech_hours = df_schedule.groupby('assigned_technician').agg({
            'estimated_duration_hours': 'sum',
            'equipment_id': 'count'
        }).reset_index()
        tech_hours.columns = ['Technician', 'Total Hours', 'Task Count']
        tech_hours = tech_hours.sort_values('Total Hours', ascending=True)
        
        # Create horizontal bar chart
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            y=tech_hours['Technician'],
            x=tech_hours['Total Hours'],
            orientation='h',
            text=tech_hours['Total Hours'].round(1),
            textposition='auto',
            marker=dict(color='#1976d2'),
            name='Hours Scheduled'
        ))
        
        fig.update_layout(
            title="Technician Utilization",
            xaxis_title="Total Hours Scheduled",
            yaxis_title="Technician",
            height=max(300, len(tech_hours) * 40),
            showlegend=False
        )
        
        return fig
    
    def export_to_excel(self, schedule_data: Dict[str, Any], filename: str) -> str:
        """Export schedule to Excel with formatting"""
        
        # Create Excel writer
        writer = pd.ExcelWriter(filename, engine='openpyxl')
        
        # Main schedule sheet
        df_schedule = pd.DataFrame(schedule_data['schedule'])
        df_schedule.to_excel(writer, sheet_name='Schedule', index=False)
        
        # Get workbook and worksheet
        workbook = writer.book
        worksheet = writer.sheets['Schedule']
        
        # Format header
        header_fill = PatternFill(start_color='1976d2', end_color='1976d2', fill_type='solid')
        header_font = Font(bold=True, color='FFFFFF')
        
        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # Auto-adjust column widths
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            worksheet.column_dimensions[column_letter].width = adjusted_width
        
        # Add priority color coding
        priority_colors = {
            'Critical': 'ffcdd2',
            'High': 'ffe0b2',
            'Medium': 'fff9c4',
            'Low': 'c8e6c9'
        }
        
        if 'priority' in df_schedule.columns:
            priority_col_idx = df_schedule.columns.get_loc('priority') + 1
            for row_idx in range(2, len(df_schedule) + 2):
                cell = worksheet.cell(row=row_idx, column=priority_col_idx)
                priority = cell.value
                if priority in priority_colors:
                    cell.fill = PatternFill(start_color=priority_colors[priority], 
                                          end_color=priority_colors[priority], 
                                          fill_type='solid')
        
        # Add summary sheet
        summary_data = {
            'Metric': [
                'Total Tasks',
                'Equipment Covered',
                'Start Date',
                'End Date',
                'Critical Priority',
                'High Priority',
                'Medium Priority',
                'Low Priority'
            ],
            'Value': [
                schedule_data['total_tasks'],
                schedule_data['equipment_coverage'],
                schedule_data['date_range'].get('start', 'N/A'),
                schedule_data['date_range'].get('end', 'N/A'),
                sum(1 for t in schedule_data['schedule'] if t.get('priority') == 'Critical'),
                sum(1 for t in schedule_data['schedule'] if t.get('priority') == 'High'),
                sum(1 for t in schedule_data['schedule'] if t.get('priority') == 'Medium'),
                sum(1 for t in schedule_data['schedule'] if t.get('priority') == 'Low')
            ]
        }
        df_summary = pd.DataFrame(summary_data)
        df_summary.to_excel(writer, sheet_name='Summary', index=False)
        
        # Format summary sheet
        summary_ws = writer.sheets['Summary']
        for cell in summary_ws[1]:
            cell.fill = header_fill
            cell.font = header_font
        
        writer.close()
        
        return filename
    
    def export_to_pdf(self, schedule_data: Dict[str, Any], filename: str) -> str:
        """Export schedule to PDF report"""
        
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        
        # Title
        pdf.set_font('Arial', 'B', 16)
        pdf.cell(0, 10, 'EV Manufacturing Equipment', ln=True, align='C')
        pdf.cell(0, 10, 'Maintenance Schedule Report', ln=True, align='C')
        pdf.ln(5)
        
        # Summary
        pdf.set_font('Arial', 'B', 12)
        pdf.cell(0, 10, 'Schedule Summary', ln=True)
        pdf.set_font('Arial', '', 10)
        pdf.cell(0, 6, f"Total Tasks: {schedule_data['total_tasks']}", ln=True)
        pdf.cell(0, 6, f"Equipment Covered: {schedule_data['equipment_coverage']}", ln=True)
        pdf.cell(0, 6, f"Period: {schedule_data['date_range'].get('start', 'N/A')} to {schedule_data['date_range'].get('end', 'N/A')}", ln=True)
        pdf.cell(0, 6, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True)
        pdf.ln(5)
        
        # Task breakdown by priority
        pdf.set_font('Arial', 'B', 12)
        pdf.cell(0, 10, 'Tasks by Priority', ln=True)
        pdf.set_font('Arial', '', 10)
        
        priority_counts = {}
        for task in schedule_data['schedule']:
            priority = task.get('priority', 'Unknown')
            priority_counts[priority] = priority_counts.get(priority, 0) + 1
        
        for priority in ['Critical', 'High', 'Medium', 'Low']:
            count = priority_counts.get(priority, 0)
            pdf.cell(0, 6, f"{priority}: {count} tasks", ln=True)
        pdf.ln(5)
        
        # Detailed schedule (first 30 tasks)
        pdf.set_font('Arial', 'B', 12)
        pdf.cell(0, 10, 'Scheduled Maintenance Tasks', ln=True)
        pdf.set_font('Arial', '', 8)
        
        # Table header
        col_widths = [50, 30, 25, 40, 35]
        headers = ['Equipment', 'Date', 'Time', 'Type', 'Technician']
        
        pdf.set_fill_color(25, 118, 210)
        pdf.set_text_color(255, 255, 255)
        pdf.set_font('Arial', 'B', 8)
        
        for i, header in enumerate(headers):
            pdf.cell(col_widths[i], 7, header, border=1, align='C', fill=True)
        pdf.ln()
        
        # Table rows
        pdf.set_text_color(0, 0, 0)
        pdf.set_font('Arial', '', 7)
        
        sorted_schedule = sorted(schedule_data['schedule'], key=lambda x: x['scheduled_date'])
        
        for task in sorted_schedule[:30]:
            equipment = task['equipment_name'][:25]
            date = task['scheduled_date']
            time = task['scheduled_time']
            maint_type = task['maintenance_type'][:20]
            tech = task['assigned_technician'][:18]
            
            pdf.cell(col_widths[0], 6, equipment, border=1)
            pdf.cell(col_widths[1], 6, date, border=1, align='C')
            pdf.cell(col_widths[2], 6, time, border=1, align='C')
            pdf.cell(col_widths[3], 6, maint_type, border=1)
            pdf.cell(col_widths[4], 6, tech, border=1)
            pdf.ln()
            
            # Add new page if needed
            if pdf.get_y() > 270:
                pdf.add_page()
                pdf.set_font('Arial', '', 7)
        
        if len(schedule_data['schedule']) > 30:
            pdf.ln(5)
            pdf.set_font('Arial', 'I', 8)
            pdf.cell(0, 6, f"... and {len(schedule_data['schedule']) - 30} more tasks (see Excel export for full list)", ln=True)
        
        # Conflicts/Warnings
        if schedule_data.get('conflicts'):
            pdf.add_page()
            pdf.set_font('Arial', 'B', 12)
            pdf.set_text_color(211, 47, 47)
            pdf.cell(0, 10, 'Scheduling Conflicts & Warnings', ln=True)
            pdf.set_text_color(0, 0, 0)
            pdf.set_font('Arial', '', 9)
            
            for conflict in schedule_data['conflicts'][:20]:
                pdf.multi_cell(0, 6, f"• {conflict}")
        
        pdf.output(filename)
        return filename

if __name__ == "__main__":
    # Test with sample data
    sample_schedule = {
        "schedule": [
            {
                "equipment_id": "BAT-001",
                "equipment_name": "Battery Cell Stacker",
                "scheduled_date": "2024-12-15",
                "scheduled_time": "22:00",
                "maintenance_type": "Preventive Inspection",
                "estimated_duration_hours": 3,
                "assigned_technician": "Sarah Chen",
                "priority": "High"
            }
        ],
        "total_tasks": 1,
        "equipment_coverage": 1,
        "date_range": {"start": "2024-12-15", "end": "2024-12-15"},
        "conflicts": []
    }
    
    viz = ScheduleVisualizer()
    fig = viz.create_gantt_chart(sample_schedule['schedule'])
    print("Visualizer ready!")
