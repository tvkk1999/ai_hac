import streamlit as st
import pandas as pd
import os
from datetime import datetime, timedelta
from data_generator import SyntheticDataGenerator
from data_processor import DataProcessor
from scheduler_agent import MaintenanceSchedulerAgent
from visualizer import ScheduleVisualizer
from risk_assessment import RiskAssessment

# Page configuration
st.set_page_config(
    page_title="EV Manufacturing Maintenance Scheduler",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1976d2;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #555;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f5f5f5;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1976d2;
    }
    .risk-critical { color: #d32f2f; font-weight: bold; }
    .risk-high { color: #f57c00; font-weight: bold; }
    .risk-medium { color: #fbc02d; font-weight: bold; }
    .risk-low { color: #388e3c; font-weight: bold; }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'processor' not in st.session_state:
    st.session_state.processor = None
if 'schedule_generated' not in st.session_state:
    st.session_state.schedule_generated = False
if 'current_schedule' not in st.session_state:
    st.session_state.current_schedule = None

def initialize_data():
    """Initialize or load data"""
    data_dir = "data"
    
    # Check if data exists
    if not os.path.exists(data_dir) or not os.path.exists(f"{data_dir}/machine_usage_logs.csv"):
        with st.spinner("Generating synthetic data for EV manufacturing equipment..."):
            generator = SyntheticDataGenerator()
            generator.save_all_data(data_dir)
            st.success("✅ Synthetic data generated successfully!")
    
    # Load data
    processor = DataProcessor()
    if processor.load_data(data_dir):
        st.session_state.processor = processor
        st.session_state.data_loaded = True
        return True
    return False

def main():
    # Header
    st.markdown('<div class="main-header">🚗 EV Manufacturing Equipment</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">AI-Powered Maintenance Schedule Generator</div>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # Data initialization
        if st.button("🔄 Initialize/Reload Data"):
            with st.spinner("Loading data..."):
                if initialize_data():
                    st.success("Data loaded successfully!")
                else:
                    st.error("Failed to load data")
        
        st.markdown("---")
        
        # Schedule parameters
        st.subheader("📅 Schedule Parameters")
        
        schedule_weeks = st.slider("Schedule Period (weeks)", 1, 12, 4)
        start_date = st.date_input("Start Date", datetime.now())
        
        max_concurrent = st.slider("Max Concurrent Tasks", 1, 10, 3)
        
        st.markdown("---")
        
        # Equipment filter
        if st.session_state.data_loaded:
            st.subheader("🔧 Equipment Filter")
            
            categories = st.session_state.processor.usage_data['category'].unique()
            selected_categories = st.multiselect(
                "Categories",
                options=categories,
                default=[]
            )
            
            if selected_categories:
                filtered_equipment = st.session_state.processor.usage_data[
                    st.session_state.processor.usage_data['category'].isin(selected_categories)
                ]['equipment_id'].unique().tolist()
            else:
                filtered_equipment = None
        else:
            filtered_equipment = None
        
        st.markdown("---")
        
        # Generate button
        if st.session_state.data_loaded:
            if st.button("🚀 Generate Schedule", type="primary"):
                end_date = start_date + timedelta(weeks=schedule_weeks)
                
                with st.spinner("AI is generating optimal maintenance schedule..."):
                    agent = MaintenanceSchedulerAgent(st.session_state.processor)
                    
                    schedule_result = agent.generate_schedule(
                        start_date=datetime.combine(start_date, datetime.min.time()),
                        end_date=end_date,
                        priority_equipment=filtered_equipment,
                        max_concurrent_maintenance=max_concurrent
                    )
                    
                    st.session_state.current_schedule = schedule_result
                    st.session_state.schedule_generated = True
                    
                st.success("✅ Schedule generated successfully!")
                st.rerun()
    
    # Main content
    if not st.session_state.data_loaded:
        st.info("👈 Click 'Initialize/Reload Data' in the sidebar to begin")
        
        # Show info about the system
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("### 📊 Data Sources")
            st.write("""
            - Machine usage logs
            - Maintenance history
            - Failure incidents
            - Production schedules
            - Resource availability
            """)
        
        with col2:
            st.markdown("### 🤖 AI Features")
            st.write("""
            - Health score calculation
            - Failure prediction
            - Schedule optimization
            - Resource allocation
            - Risk assessment
            """)
        
        with col3:
            st.markdown("### 📈 Outputs")
            st.write("""
            - Gantt charts
            - Calendar views
            - Excel exports
            - PDF reports
            - Recommendations
            """)
        
        return
    
    # Tabs for different views
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Equipment Dashboard",
        "📅 Schedule",
        "⚠️ Risk Assessment",
        "💡 Recommendations",
        "📥 Export"
    ])
    
    # Tab 1: Equipment Dashboard
    with tab1:
        st.header("Equipment Health Overview")
        
        # Get equipment summary
        equipment_summary = st.session_state.processor.get_equipment_summary()
        
        # Key metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "Total Equipment",
                len(equipment_summary)
            )
        
        with col2:
            critical_count = len(equipment_summary[equipment_summary['risk_level'] == 'Critical'])
            st.metric(
                "Critical Risk",
                critical_count,
                delta=f"-{critical_count}" if critical_count > 0 else "0",
                delta_color="inverse"
            )
        
        with col3:
            avg_health = equipment_summary['health_score'].mean()
            st.metric(
                "Avg Health Score",
                f"{avg_health:.1f}/100"
            )
        
        with col4:
            overdue = len(equipment_summary[equipment_summary['days_until_maintenance'] < 0])
            st.metric(
                "Overdue Maintenance",
                overdue,
                delta=f"-{overdue}" if overdue > 0 else "0",
                delta_color="inverse"
            )
        
        st.markdown("---")
        
        # Equipment table with color coding
        st.subheader("Equipment Status")
        
        def highlight_risk(row):
            if row['risk_level'] == 'Critical':
                return ['background-color: #ffcdd2'] * len(row)
            elif row['risk_level'] == 'High':
                return ['background-color: #ffe0b2'] * len(row)
            elif row['risk_level'] == 'Medium':
                return ['background-color: #fff9c4'] * len(row)
            else:
                return ['background-color: #c8e6c9'] * len(row)
        
        # Sort by health score
        display_df = equipment_summary.sort_values('health_score')
        
        st.dataframe(
            display_df.style.apply(highlight_risk, axis=1),
            use_container_width=True,
            height=400
        )
        
        # Category breakdown
        st.markdown("---")
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Equipment by Category")
            category_counts = equipment_summary['category'].value_counts()
            st.bar_chart(category_counts)
        
        with col2:
            st.subheader("Risk Level Distribution")
            risk_counts = equipment_summary['risk_level'].value_counts()
            st.bar_chart(risk_counts)
    
    # Tab 2: Schedule
    with tab2:
        if not st.session_state.schedule_generated:
            st.info("👈 Configure parameters and click 'Generate Schedule' to create a maintenance schedule")
        else:
            st.header("Generated Maintenance Schedule")
            
            schedule = st.session_state.current_schedule
            
            # Summary metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Tasks", schedule['total_tasks'])
            
            with col2:
                st.metric("Equipment Covered", schedule['equipment_coverage'])
            
            with col3:
                if schedule['date_range']['start']:
                    st.metric("Start Date", schedule['date_range']['start'])
            
            with col4:
                if schedule['date_range']['end']:
                    st.metric("End Date", schedule['date_range']['end'])
            
            st.markdown("---")
            
            # Visualizations
            visualizer = ScheduleVisualizer()
            
            # Gantt Chart
            st.subheader("📊 Gantt Chart View")
            gantt_fig = visualizer.create_gantt_chart(schedule['schedule'])
            st.plotly_chart(gantt_fig, use_container_width=True)
            
            st.markdown("---")
            
            # Calendar and Resource views
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📅 Calendar Heatmap")
                calendar_fig = visualizer.create_calendar_view(schedule['schedule'])
                st.plotly_chart(calendar_fig, use_container_width=True)
            
            with col2:
                st.subheader("👥 Resource Utilization")
                resource_fig = visualizer.create_resource_utilization_chart(schedule['schedule'])
                st.plotly_chart(resource_fig, use_container_width=True)
            
            st.markdown("---")
            
            # Detailed schedule table
            st.subheader("📋 Detailed Schedule")
            df_schedule = pd.DataFrame(schedule['schedule'])
            st.dataframe(df_schedule, use_container_width=True, height=400)
            
            # Conflicts
            if schedule['conflicts']:
                st.warning(f"⚠️ {len(schedule['conflicts'])} scheduling conflicts detected")
                with st.expander("View Conflicts"):
                    for conflict in schedule['conflicts']:
                        st.write(f"• {conflict}")
    
    # Tab 3: Risk Assessment
    with tab3:
        st.header("Risk Assessment")
        
        risk_assessor = RiskAssessment(st.session_state.processor)
        
        # Overall risk if schedule exists
        if st.session_state.schedule_generated:
            st.subheader("Schedule Risk Analysis")
            
            risk_analysis = risk_assessor.assess_schedule_risk(st.session_state.current_schedule)
            
            # Risk level indicator
            risk_level = risk_analysis['overall_risk_level']
            if risk_level == "HIGH":
                st.error(f"🔴 {risk_level} RISK: {risk_analysis['assessment']}")
            elif risk_level == "MODERATE":
                st.warning(f"🟡 {risk_level} RISK: {risk_analysis['assessment']}")
            else:
                st.success(f"🟢 {risk_level} RISK: {risk_analysis['assessment']}")
            
            # Metrics
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Schedule Coverage", f"{risk_analysis['schedule_coverage_pct']:.1f}%")
            
            with col2:
                st.metric("Unscheduled Equipment", risk_analysis['unscheduled_equipment'])
            
            with col3:
                st.metric("High-Risk Unscheduled", len(risk_analysis['high_risk_unscheduled']))
            
            # High-risk unscheduled equipment
            if risk_analysis['high_risk_unscheduled']:
                st.subheader("⚠️ High-Risk Unscheduled Equipment")
                df_risk = pd.DataFrame(risk_analysis['high_risk_unscheduled'])
                st.dataframe(df_risk, use_container_width=True)
        
        st.markdown("---")
        
        # Individual equipment risk
        st.subheader("Equipment Failure Probability")
        
        # Select equipment
        equipment_ids = st.session_state.processor.usage_data['equipment_id'].unique()
        selected_eq = st.selectbox("Select Equipment", equipment_ids)
        
        days_ahead = st.slider("Prediction Period (days)", 7, 90, 30)
        
        if st.button("Calculate Risk"):
            with st.spinner("Calculating failure probability..."):
                risk_data = risk_assessor.calculate_failure_probability(selected_eq, days_ahead)
            
            # Display results
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric(
                    "Failure Probability",
                    f"{risk_data['failure_probability_pct']:.2f}%"
                )
            
            with col2:
                st.metric(
                    "Risk Score",
                    f"{risk_data['risk_score']:.1f}/100"
                )
            
            with col3:
                st.metric(
                    "Expected Downtime",
                    f"{risk_data['expected_downtime_hours']:.1f} hrs"
                )
            
            # Recommendation
            st.info(f"💡 **Recommendation:** {risk_data['recommendation']}")
            
            # Contributing factors
            st.subheader("Contributing Factors")
            factors_df = pd.DataFrame([risk_data['contributing_factors']])
            st.dataframe(factors_df, use_container_width=True)
    
    # Tab 4: Recommendations
    with tab4:
        st.header("AI-Powered Recommendations")
        
        if not st.session_state.schedule_generated:
            st.info("Generate a schedule first to receive recommendations")
        else:
            # LLM-based recommendations
            st.subheader("🤖 AI Analysis")
            
            with st.spinner("Generating recommendations..."):
                agent = MaintenanceSchedulerAgent(st.session_state.processor)
                ai_recommendations = agent.generate_recommendations(st.session_state.current_schedule)
            
            for rec in ai_recommendations:
                st.write(rec)
            
            st.markdown("---")
            
            # Risk-based recommendations
            st.subheader("⚠️ Risk-Based Recommendations")
            
            risk_assessor = RiskAssessment(st.session_state.processor)
            risk_analysis = risk_assessor.assess_schedule_risk(st.session_state.current_schedule)
            optimization_recs = risk_assessor.generate_optimization_recommendations(
                st.session_state.current_schedule,
                risk_analysis
            )
            
            for rec in optimization_recs:
                if "🔴" in rec or "URGENT" in rec:
                    st.error(rec)
                elif "⚠️" in rec or "⚡" in rec:
                    st.warning(rec)
                else:
                    st.info(rec)
    
    # Tab 5: Export
    with tab5:
        st.header("Export Schedule")
        
        if not st.session_state.schedule_generated:
            st.info("Generate a schedule first to export")
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📊 Excel Export")
                st.write("Export complete schedule with formatting")
                
                excel_filename = f"maintenance_schedule_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                
                if st.button("Generate Excel File"):
                    with st.spinner("Creating Excel file..."):
                        visualizer = ScheduleVisualizer()
                        output_path = visualizer.export_to_excel(
                            st.session_state.current_schedule,
                            excel_filename
                        )
                        st.success(f"✅ Excel file created: {output_path}")
                        
                        # Provide download
                        with open(output_path, 'rb') as f:
                            st.download_button(
                                "⬇️ Download Excel",
                                f,
                                file_name=excel_filename,
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
            
            with col2:
                st.subheader("📄 PDF Export")
                st.write("Export schedule report as PDF")
                
                pdf_filename = f"maintenance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
                
                if st.button("Generate PDF Report"):
                    with st.spinner("Creating PDF report..."):
                        visualizer = ScheduleVisualizer()
                        output_path = visualizer.export_to_pdf(
                            st.session_state.current_schedule,
                            pdf_filename
                        )
                        st.success(f"✅ PDF report created: {output_path}")
                        
                        # Provide download
                        with open(output_path, 'rb') as f:
                            st.download_button(
                                "⬇️ Download PDF",
                                f,
                                file_name=pdf_filename,
                                mime="application/pdf"
                            )
            
            st.markdown("---")
            
            # Export raw data
            st.subheader("📁 Raw Data Export")
            
            df_schedule = pd.DataFrame(st.session_state.current_schedule['schedule'])
            csv = df_schedule.to_csv(index=False)
            
            st.download_button(
                "⬇️ Download as CSV",
                csv,
                file_name=f"schedule_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )

if __name__ == "__main__":
    main()
