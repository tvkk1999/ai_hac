# app.py
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
from typing import List, Dict, Any, Optional

# Removed litellm import per your request.
# The DataProcessor now accepts an llm and an embedding_model instance (from your SDK / LangChain wrappers).

class DataProcessor:
    """Process and analyze manufacturing data for maintenance scheduling"""
    
    def __init__(self, llm: Optional[Any] = None, embedding_model: Optional[Any] = None):
        self.usage_data = None
        self.maintenance_data = None
        self.failure_data = None
        self.production_data = None
        self.resource_data = None
        
        # External models supplied by caller
        self.llm = llm
        self.embedding_model = embedding_model
    
    def load_data(self, data_dir="data"):
        """Load all datasets"""
        try:
            self.usage_data = pd.read_csv(f"{data_dir}/machine_usage_logs.csv")
            self.maintenance_data = pd.read_csv(f"{data_dir}/maintenance_records.csv")
            self.failure_data = pd.read_csv(f"{data_dir}/failure_incidents.csv")
            self.production_data = pd.read_csv(f"{data_dir}/production_schedule.csv")
            self.resource_data = pd.read_csv(f"{data_dir}/resource_availability.csv")
            
            # Convert date columns
            self.usage_data['date'] = pd.to_datetime(self.usage_data['date'])
            self.maintenance_data['date'] = pd.to_datetime(self.maintenance_data['date'])
            self.failure_data['date'] = pd.to_datetime(self.failure_data['date'])
            self.production_data['date'] = pd.to_datetime(self.production_data['date'])
            
            print("All data loaded successfully!")
            return True
        except Exception as e:
            print(f"Error loading data: {e}")
            return False
    
    def calculate_equipment_health_score(self, equipment_id: str) -> Dict[str, Any]:
        """Calculate comprehensive health score for equipment"""
        
        # Get recent usage data (last 30 days)
        recent_usage = self.usage_data[
            (self.usage_data['equipment_id'] == equipment_id) &
            (self.usage_data['date'] >= datetime.now() - timedelta(days=30))
        ].sort_values('date').reset_index(drop=True)
        
        if recent_usage.empty:
            return {"equipment_id": equipment_id, "health_score": 50, "risk_level": "Unknown", "factors": {}}
        
        # Calculate various health factors
        factors = {}
        
        # 1. Vibration trend (lower is better)
        avg_vibration = float(recent_usage['vibration_level'].mean()) if 'vibration_level' in recent_usage.columns else 0.0
        
        # compute trend robustly: compare last 7-day mean vs first 7-day mean if available
        def safe_window_mean(series, start_idx, end_idx):
            if len(series) == 0:
                return 0.0
            start_idx = max(0, min(start_idx, len(series)-1))
            end_idx = max(0, min(end_idx, len(series)))
            window = series.iloc[start_idx:end_idx]
            return float(window.mean()) if not window.empty else 0.0
        
        # first 7 rows mean and last 7 rows mean
        first7_mean = safe_window_mean(recent_usage['vibration_level'], 0, 7)
        last7_mean = safe_window_mean(recent_usage['vibration_level'], max(0, len(recent_usage)-7), len(recent_usage))
        vibration_trend = last7_mean - first7_mean
        
        factors['vibration_score'] = max(0, 100 - (avg_vibration * 100) - (vibration_trend * 200))
        
        # 2. Temperature stability
        avg_temp = float(recent_usage['temperature_avg'].mean()) if 'temperature_avg' in recent_usage.columns else 0.0
        temp_std = float(recent_usage['temperature_avg'].std()) if 'temperature_avg' in recent_usage.columns else 0.0
        factors['temperature_score'] = max(0, 100 - (avg_temp - 50) - (temp_std * 2))
        
        # 3. Error frequency - support numeric or string-coded error entries
        if 'error_codes' in recent_usage.columns:
            # If error_codes are numeric counts:
            try:
                error_count = int(recent_usage['error_codes'].astype(float).sum())
            except Exception:
                # fallback: count non-empty error strings
                error_count = int(recent_usage['error_codes'].astype(str).apply(lambda x: 0 if x in ['', 'nan', 'None', 'NoneType'] else 1).sum())
        else:
            error_count = 0
        factors['error_score'] = max(0, 100 - (error_count * 5))
        
        # 4. Maintenance history
        recent_maintenance = self.maintenance_data[
            (self.maintenance_data['equipment_id'] == equipment_id) &
            (self.maintenance_data['date'] >= datetime.now() - timedelta(days=90))
        ]
        days_since_last_maintenance = (datetime.now() - recent_maintenance['date'].max()).days if not recent_maintenance.empty else 90
        factors['maintenance_score'] = max(0, 100 - days_since_last_maintenance)
        
        # 5. Failure history
        equipment_failures = self.failure_data[self.failure_data['equipment_id'] == equipment_id] if 'equipment_id' in self.failure_data.columns else pd.DataFrame()
        recent_failures = equipment_failures[equipment_failures['date'] >= datetime.now() - timedelta(days=180)] if not equipment_failures.empty else pd.DataFrame()
        factors['failure_score'] = max(0, 100 - (len(recent_failures) * 15))
        
        # Calculate weighted health score
        health_score = (
            factors['vibration_score'] * 0.25 +
            factors['temperature_score'] * 0.20 +
            factors['error_score'] * 0.20 +
            factors['maintenance_score'] * 0.20 +
            factors['failure_score'] * 0.15
        )
        
        # Determine risk level
        if health_score >= 80:
            risk_level = "Low"
        elif health_score >= 60:
            risk_level = "Medium"
        elif health_score >= 40:
            risk_level = "High"
        else:
            risk_level = "Critical"
        
        return {
            "equipment_id": equipment_id,
            "health_score": round(health_score, 2),
            "risk_level": risk_level,
            "factors": factors,
            "days_since_maintenance": days_since_last_maintenance,
            "recent_failures": len(recent_failures),
            "avg_vibration": round(avg_vibration, 3),
            "avg_temperature": round(avg_temp, 2)
        }
    
    def predict_next_maintenance(self, equipment_id: str) -> Dict[str, Any]:
        """Predict when maintenance is needed based on historical patterns"""
        
        # Get historical maintenance intervals
        equipment_maintenance = self.maintenance_data[
            self.maintenance_data['equipment_id'] == equipment_id
        ].sort_values('date').reset_index(drop=True)
        
        if len(equipment_maintenance) < 2:
            return {
                "equipment_id": equipment_id,
                "predicted_date": datetime.now() + timedelta(days=30),
                "days_until_maintenance": 30,
                "confidence": "Low",
                "recommended_type": "Preventive Inspection",
                "health_score": None,
                "last_maintenance_date": None,
                "avg_interval_days": None
            }
        
        # Calculate average interval between maintenance
        equipment_maintenance['days_since_last'] = equipment_maintenance['date'].diff().dt.days
        avg_interval = float(equipment_maintenance['days_since_last'].mean())
        
        # Get last maintenance date
        last_maintenance = equipment_maintenance['date'].max()
        days_since = (datetime.now() - last_maintenance).days
        
        # Get health score
        health = self.calculate_equipment_health_score(equipment_id)
        
        # Adjust prediction based on health score
        if health['health_score'] < 50:
            predicted_days = max(7, avg_interval * 0.5)  # Urgent
            confidence = "High"
        elif health['health_score'] < 70:
            predicted_days = avg_interval * 0.75
            confidence = "Medium"
        else:
            predicted_days = avg_interval
            confidence = "Medium"
        
        predicted_date = last_maintenance + timedelta(days=predicted_days)
        
        # Recommend maintenance type based on history and health
        maintenance_types = equipment_maintenance['maintenance_type'].value_counts() if 'maintenance_type' in equipment_maintenance.columns else pd.Series(dtype=int)
        recommended_type = maintenance_types.index[0] if not maintenance_types.empty else "Preventive Inspection"
        
        return {
            "equipment_id": equipment_id,
            "predicted_date": predicted_date,
            "days_until_maintenance": (predicted_date - datetime.now()).days,
            "confidence": confidence,
            "recommended_type": recommended_type,
            "health_score": health['health_score'],
            "last_maintenance_date": last_maintenance.strftime("%Y-%m-%d"),
            "avg_interval_days": round(avg_interval, 1)
        }
    
    def get_equipment_summary(self) -> pd.DataFrame:
        """Get summary of all equipment with health scores and predictions"""
        equipment_ids = self.usage_data['equipment_id'].unique()
        
        summaries = []
        for eq_id in equipment_ids:
            health = self.calculate_equipment_health_score(eq_id)
            prediction = self.predict_next_maintenance(eq_id)
            
            # Get equipment name (first matching row)
            eq_info = self.usage_data[self.usage_data['equipment_id'] == eq_id].iloc[0]
            
            summaries.append({
                "equipment_id": eq_id,
                "equipment_name": eq_info.get('equipment_name', 'Unknown'),
                "category": eq_info.get('category', 'Unknown'),
                "health_score": health['health_score'],
                "risk_level": health['risk_level'],
                "days_since_maintenance": health['days_since_maintenance'],
                "predicted_maintenance_date": prediction['predicted_date'].strftime("%Y-%m-%d") if isinstance(prediction['predicted_date'], datetime) else str(prediction['predicted_date']),
                "days_until_maintenance": prediction['days_until_maintenance'],
                "recommended_type": prediction['recommended_type']
            })
        
        return pd.DataFrame(summaries)
    
    def create_equipment_embeddings(self, equipment_data: Dict[str, Any]) -> List[float]:
        """Create embeddings for equipment data using the provided embedding_model"""
        try:
            if self.embedding_model is None:
                raise RuntimeError("No embedding_model provided to DataProcessor.")
            
            # Create a comprehensive text representation
            text = f"""
            Equipment: {equipment_data.get('equipment_name', 'Unknown')}
            Category: {equipment_data.get('category', 'Unknown')}
            Health Score: {equipment_data.get('health_score', 0)}
            Risk Level: {equipment_data.get('risk_level', 'Unknown')}
            Days Since Maintenance: {equipment_data.get('days_since_maintenance', 0)}
            Recent Failures: {equipment_data.get('recent_failures', 0)}
            Average Vibration: {equipment_data.get('avg_vibration', 0)}
            Average Temperature: {equipment_data.get('avg_temperature', 0)}
            Recommended Maintenance: {equipment_data.get('recommended_type', 'Unknown')}
            """.strip()
            
            # Different embedding wrappers expose different method names:
            # - LangChain's OpenAIEmbeddings: .embed_documents([texts])
            # - Some lightweight wrappers: .embed([text]) or .embed_query(text)
            emb = None
            if hasattr(self.embedding_model, "embed_documents"):
                emb_list = self.embedding_model.embed_documents([text])
                emb = emb_list[0]
            elif hasattr(self.embedding_model, "embed"):
                emb_list = self.embedding_model.embed([text])
                emb = emb_list[0]
            elif hasattr(self.embedding_model, "embed_query"):
                emb = self.embedding_model.embed_query(text)
            else:
                # attempt a generic call (may raise)
                emb = self.embedding_model([text])
            
            return emb
        except Exception as e:
            print(f"Error creating embeddings: {e}")
            # Return zero vector as fallback (size guessed; if you know exact dim, set it)
            # If embedding_model exists and has attribute 'dimension' or 'embed_dim', use it:
            dim_guess = 1536
            try:
                if hasattr(self.embedding_model, "dimension"):
                    dim_guess = int(self.embedding_model.dimension)
                elif hasattr(self.embedding_model, "embed_dim"):
                    dim_guess = int(self.embedding_model.embed_dim)
            except Exception:
                pass
            return [0.0] * dim_guess
    
    def find_production_windows(self, start_date: datetime, end_date: datetime) -> List[Dict[str, Any]]:
        """Find suitable maintenance windows based on production schedule"""
        start_ts = pd.to_datetime(start_date)
        end_ts   = pd.to_datetime(end_date)
        schedule = self.production_data[
            (self.production_data['date'] >= start_ts) &
            (self.production_data['date'] <= end_ts)
        ]
        
        windows = []
        for _, row in schedule.iterrows():
            # Prefer weekends and low-priority days
            priority_score = 100
            
            if row.get('day_of_week') in ['Saturday', 'Sunday'] if isinstance(row, dict) else row['day_of_week'] in ['Saturday', 'Sunday']:
                priority_score -= 30
            
            if row['production_priority'] == 'Normal':
                priority_score -= 20
            elif row['production_priority'] == 'Rush Order':
                priority_score += 30
            
            if row.get('planned_maintenance_window', None) is not None if isinstance(row, dict) else pd.notna(row['planned_maintenance_window']):
                priority_score -= 40
            
            windows.append({
                "date": row['date'].strftime("%Y-%m-%d"),
                "day_of_week": row['day_of_week'],
                "production_target": row.get('total_daily_target', row.get('total_daily_target', None)) if isinstance(row, dict) else row['total_daily_target'],
                "priority": row['production_priority'],
                "suitability_score": priority_score,
                "maintenance_window": row.get('planned_maintenance_window', None) if isinstance(row, dict) else row['planned_maintenance_window']
            })
        
        return sorted(windows, key=lambda x: x['suitability_score'])

if __name__ == "__main__":
    # Example usage:
    # IMPORTANT: Do NOT hardcode API keys in production. Use environment variables or a config file.
    #
    # You showed these objects in your message; construct them in your app and pass them here:
    #
    # from some_http_client_library import client
    # from langchain.chat_models import ChatOpenAI         # or whichever ChatOpenAI you use
    # from langchain.embeddings import OpenAIEmbeddings   # or your wrapper
    #
    # client = <your_http_client_with_certs_and_proxy_if_needed>
    # llm = ChatOpenAI(
    #     base_url="https://genailab.tcs.in",
    #     model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    #     api_key="YOUR_KEY",
    #     http_client=client
    # )
    #
    # embedding_model = OpenAIEmbeddings(
    #     base_url="https://genailab.tcs.in",
    #     model="azure/genailab-maas-text-embedding-3-large",
    #     api_key="YOUR_KEY",
    #     http_client=client
    # )
    #
    # Then:
    #
    # processor = DataProcessor(llm=llm, embedding_model=embedding_model)
    # if processor.load_data():
    #     summary = processor.get_equipment_summary()
    #     print("\nEquipment Summary:")
    #     print(summary.to_string())
    #
    # And to create embeddings for an equipment row:
    # emb = processor.create_equipment_embeddings({
    #     "equipment_name": "Pump A",
    #     "category": "Pump",
    #     "health_score": 72.5,
    #     "risk_level": "Medium",
    #     "days_since_maintenance": 12,
    #     "recent_failures": 1,
    #     "avg_vibration": 0.012,
    #     "avg_temperature": 52.3,
    #     "recommended_type": "Bearing check"
    # })
    #
    # print("Embedding vector length:", len(emb))
    pass
