import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import json
from data_processor import DataProcessor
from config import LLM_MODEL, AZURE_API_KEY
import httpx 
client = httpx.Client(verify=False)
from langchain_openai import ChatOpenAI

class MaintenanceSchedulerAgent:
    """AI Agent for generating optimal maintenance schedules using Azure LLMs"""
    
    def __init__(self, data_processor: DataProcessor):
        self.processor = data_processor
        self.llm = ChatOpenAI(
                    base_url="https://genailab.tcs.in",
                    model = LLM_MODEL,
                    api_key=AZURE_API_KEY,
                    http_client = client)

    
    def generate_schedule(self, 
                         start_date: datetime, 
                         end_date: datetime,
                         priority_equipment: Optional[List[str]] = None,
                         max_concurrent_maintenance: int = 3) -> Dict[str, Any]:
        """Generate optimized maintenance schedule using AI"""
        
        # Get equipment summary
        equipment_summary = self.processor.get_equipment_summary()
        
        # Filter priority equipment if specified
        if priority_equipment is not None and len(priority_equipment) > 0:
            equipment_summary = equipment_summary[
                equipment_summary['equipment_id'].isin(priority_equipment)
            ]
        
        # Get production windows
        production_windows = self.processor.find_production_windows(start_date, end_date)
        
        # Get resource availability
        resources = self.processor.resource_data
        
        # Prepare context for LLM
        context = self._prepare_scheduling_context(
            equipment_summary, 
            production_windows, 
            resources,
            start_date,
            end_date
        )
        
        # Generate schedule using reasoning model
        schedule = self._call_llm_scheduler(context, max_concurrent_maintenance)
        
        # If schedule is empty or failed, use enhanced fallback
        if not schedule or len(schedule) == 0:
            print("Empty schedule from LLM, using fallback...")
            schedule = self._generate_fallback_schedule(start_date, end_date)
        
        # Post-process and validate schedule
        validated_schedule = self._validate_and_optimize_schedule(schedule, equipment_summary, resources)
        
        return validated_schedule
    
    def _prepare_scheduling_context(self,
                                    equipment_summary: pd.DataFrame,
                                    production_windows: List[Dict],
                                    resources: pd.DataFrame,
                                    start_date: datetime,
                                    end_date: datetime) -> str:
        """Prepare comprehensive context for the LLM"""
        
        context = f"""
# EV Manufacturing Maintenance Scheduling Task

## Objective
Generate an optimal maintenance schedule from {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')} that:
1. Prioritizes equipment based on health scores and risk levels
2. Minimizes impact on production targets
3. Efficiently allocates technician resources
4. Prevents equipment failures through timely maintenance

## Equipment Status
Total equipment requiring attention: {len(equipment_summary)}

### High Priority Equipment (Health Score < 60 or Critical/High Risk):
"""
        high_priority = equipment_summary[
            (equipment_summary['health_score'] < 60) | 
            (equipment_summary['risk_level'].isin(['Critical', 'High']))
        ].sort_values('health_score')
        
        for _, eq in high_priority.iterrows():
            context += f"""
- {eq['equipment_id']} ({eq['equipment_name']}):
  * Health Score: {eq['health_score']}/100
  * Risk Level: {eq['risk_level']}
  * Days Since Last Maintenance: {eq['days_since_maintenance']}
  * Predicted Due: {eq['predicted_maintenance_date']} ({eq['days_until_maintenance']} days)
  * Recommended: {eq['recommended_type']}
"""
        
        context += f"""

### Medium Priority Equipment (Health Score 60-79):
"""
        medium_priority = equipment_summary[
            (equipment_summary['health_score'] >= 60) & 
            (equipment_summary['health_score'] < 80)
        ].sort_values('health_score')
        
        for _, eq in medium_priority.head(10).iterrows():
            context += f"- {eq['equipment_id']} ({eq['equipment_name']}): Health {eq['health_score']}/100, Due {eq['predicted_maintenance_date']}\n"
        
        if len(medium_priority) > 10:
            context += f"... and {len(medium_priority) - 10} more medium priority items\n"
        
        context += f"""

## Production Schedule Constraints
Best maintenance windows (low production impact):
"""
        for window in production_windows[:15]:
            context += f"""
- {window['date']} ({window['day_of_week']}): 
  Target={window['production_target']} units, Priority={window['priority']}, 
  Suitability Score={window['suitability_score']}/100
  Planned Window: {window['maintenance_window'] or 'Flexible'}
"""
        
        context += f"""

## Available Resources
Technicians and their specialties:
"""
        tech_summary = resources.groupby(['technician_name', 'skill_level']).agg({
            'specialty': lambda x: ', '.join(x),
            'available_shifts': 'first',
            'hourly_rate': 'mean'
        }).reset_index()
        
        for _, tech in tech_summary.iterrows():
            context += f"- {tech['technician_name']} ({tech['skill_level']}): {tech['specialty']} - {tech['available_shifts']} shifts\n"
        
        context += """

## Scheduling Requirements
1. Schedule high-risk equipment ASAP (within 7 days if possible)
2. Avoid scheduling more than 3 concurrent maintenance activities
3. Prefer weekend or low-production days
4. Match technician skills to equipment needs:
   - Battery/Motor equipment → Electrical specialists
   - Welding/Assembly → Mechanical specialists
   - All equipment → Software/Calibration for updates
5. Consider typical maintenance durations (1-8 hours depending on type)
6. Allow buffer time between maintenance on same production line

## Output Format Required
Provide a JSON array of maintenance tasks with this structure:
[
  {
    "equipment_id": "BAT-001",
    "equipment_name": "Battery Cell Stacker",
    "scheduled_date": "2024-12-15",
    "scheduled_time": "22:00",
    "maintenance_type": "Preventive Inspection",
    "estimated_duration_hours": 3,
    "assigned_technician": "Sarah Chen",
    "priority": "High",
    "reason": "Health score 45/100, overdue by 5 days"
  }
]
"""
        return context
    
    def _call_llm_scheduler(self, context: str, max_concurrent: int) -> List[Dict[str, Any]]:
        """Call LLM to generate schedule"""
        try:
            # Check if LLM is properly configured
            if not self.llm:
                print("Warning: LLM not configured. Using fallback schedule.")
                return self._generate_fallback_schedule()
            
            messages = [
                {
                    "role": "system",
                    "content": """You are an expert maintenance scheduling AI for EV manufacturing facilities. 
You optimize maintenance schedules to balance equipment health, production continuity, and resource efficiency.
You MUST respond with valid JSON array only, no other text."""
                },
                {
                    "role": "user",
                    "content": context + f"\n\nGenerate the optimal maintenance schedule. Maximum {max_concurrent} concurrent tasks."
                }
            ]
            
            # Use LLM instance from config with custom HTTP client
            print(f"Calling LLM model: {LLM_MODEL}...")
            response = self.llm.invoke(messages)
            
            response_text = response.content.strip()
            print(f"LLM response received ({len(response_text)} chars)")
            
            # Extract JSON from response
            if "```json" in response_text:
                response_text = response_text.split("```json")[1].split("```")[0].strip()
            elif "```" in response_text:
                response_text = response_text.split("```")[1].split("```")[0].strip()
            
            schedule = json.loads(response_text)
            print(f"Successfully parsed {len(schedule)} tasks from LLM")
            return schedule
            
        except Exception as e:
            print(f"Error calling LLM: {e}")
            print(f"Using fallback schedule generation instead")
            # Return fallback schedule
            return self._generate_fallback_schedule()
    
    def _generate_fallback_schedule(self, start_date: datetime = None, end_date: datetime = None) -> List[Dict[str, Any]]:
        """Generate basic schedule if LLM fails - uses actual dates and more intelligent scheduling"""
        print("Generating intelligent fallback schedule...")
        equipment_summary = self.processor.get_equipment_summary()
        
        # Sort by priority: Critical > High > days until maintenance
        equipment_summary['priority_score'] = equipment_summary.apply(
            lambda x: (
                1000 if x['risk_level'] == 'Critical' else
                500 if x['risk_level'] == 'High' else
                100 if x['risk_level'] == 'Medium' else 0
            ) - x['days_until_maintenance'],
            axis=1
        )
        
        high_priority = equipment_summary.sort_values('priority_score', ascending=False).head(20)
        
        schedule = []
        base_date = start_date if start_date else datetime.now()
        
        # Get available technicians
        techs = self.processor.resource_data['technician_name'].unique().tolist() if hasattr(self.processor, 'resource_data') else ['TBD']
        
        for idx, (_, eq) in enumerate(high_priority.iterrows()):
            # Spread tasks over the schedule period
            days_offset = idx * 2  # Every 2 days
            scheduled_date = base_date + timedelta(days=days_offset)
            
            # Assign time based on production window (prefer night shift)
            scheduled_time = "22:00" if idx % 3 != 2 else "14:00"
            
            # Assign technician round-robin
            tech = techs[idx % len(techs)] if techs else "TBD"
            
            # Duration varies by maintenance type
            duration_map = {
                "Preventive Inspection": 2,
                "Calibration": 3,
                "Component Replacement": 4,
                "Software Update": 1.5,
            }
            duration = duration_map.get(eq['recommended_type'], 3)
            
            schedule.append({
                "equipment_id": eq['equipment_id'],
                "equipment_name": eq['equipment_name'],
                "scheduled_date": scheduled_date.strftime("%Y-%m-%d"),
                "scheduled_time": scheduled_time,
                "maintenance_type": eq['recommended_type'],
                "estimated_duration_hours": duration,
                "assigned_technician": tech,
                "priority": eq['risk_level'],
                "reason": f"Health score {eq['health_score']:.1f}/100, {eq['days_until_maintenance']} days until due"
            })
        
        print(f"Generated {len(schedule)} fallback tasks")
        return schedule
    
    def _validate_and_optimize_schedule(self, 
                                       schedule: List[Dict[str, Any]],
                                       equipment_summary: pd.DataFrame,
                                       resources: pd.DataFrame) -> Dict[str, Any]:
        """Validate and optimize the generated schedule"""
        
        validated_tasks = []
        conflicts = []
        
        # Track concurrent tasks per day
        daily_tasks = {}
        
        for task in schedule:
            date = task.get('scheduled_date')
            
            if not date:
                conflicts.append(f"Task for {task.get('equipment_id')} missing date")
                continue
            
            # Count concurrent tasks
            if date not in daily_tasks:
                daily_tasks[date] = []
            daily_tasks[date].append(task)
            
            # Validate technician assignment
            tech_name = task.get('assigned_technician')
            if tech_name and tech_name != 'TBD':
                tech_skills = resources[resources['technician_name'] == tech_name]
                if tech_skills.empty:
                    task['assigned_technician'] = 'TBD'
                    conflicts.append(f"Technician {tech_name} not found, reassigning")
            
            validated_tasks.append(task)
        
        # Check for over-scheduling
        for date, tasks in daily_tasks.items():
            if len(tasks) > 5:
                conflicts.append(f"Warning: {len(tasks)} tasks scheduled on {date}, may need redistribution")
        
        return {
            "schedule": validated_tasks,
            "total_tasks": len(validated_tasks),
            "date_range": {
                "start": min([t['scheduled_date'] for t in validated_tasks]) if validated_tasks else None,
                "end": max([t['scheduled_date'] for t in validated_tasks]) if validated_tasks else None
            },
            "conflicts": conflicts,
            "equipment_coverage": len(set([t['equipment_id'] for t in validated_tasks])),
            "generated_at": datetime.now().isoformat()
        }
    
    def generate_recommendations(self, schedule_result: Dict[str, Any]) -> List[str]:
        """Generate AI-powered recommendations for schedule optimization"""
        try:
            schedule_summary = f"""
Maintenance Schedule Summary:
- Total Tasks: {schedule_result['total_tasks']}
- Equipment Covered: {schedule_result['equipment_coverage']}
- Date Range: {schedule_result['date_range'].get('start')} to {schedule_result['date_range'].get('end')}
- Conflicts/Warnings: {len(schedule_result['conflicts'])}

Tasks by Priority:
"""
            priority_counts = {}
            for task in schedule_result['schedule']:
                priority = task.get('priority', 'Unknown')
                priority_counts[priority] = priority_counts.get(priority, 0) + 1
            
            for priority, count in priority_counts.items():
                schedule_summary += f"- {priority}: {count} tasks\n"
            
            if schedule_result['conflicts']:
                schedule_summary += "\nConflicts:\n"
                for conflict in schedule_result['conflicts'][:5]:
                    schedule_summary += f"- {conflict}\n"
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a maintenance scheduling expert. Provide 5-7 concise, actionable recommendations to improve this schedule."
                },
                {
                    "role": "user",
                    "content": schedule_summary + "\n\nProvide recommendations as a numbered list."
                }
            ]
            
            response = self.llm.invoke(messages)
            
            recommendations_text = response.content.strip()
            # Parse numbered list
            recommendations = [line.strip() for line in recommendations_text.split('\n') if line.strip() and line[0].isdigit()]
            
            return recommendations
            
        except Exception as e:
            print(f"Error generating recommendations: {e}")
            return [
                "1. Review high-priority equipment scheduled more than 7 days out",
                "2. Consider batching maintenance tasks on the same production line",
                "3. Verify technician skill alignment with equipment requirements",
                "4. Schedule critical equipment during planned maintenance windows",
                "5. Monitor concurrent tasks to avoid resource conflicts"
            ]

if __name__ == "__main__":
    processor = DataProcessor()
    if processor.load_data():
        agent = MaintenanceSchedulerAgent(processor)
        
        start_date = datetime.now()
        end_date = start_date + timedelta(days=30)
        
        print("Generating maintenance schedule...")
        result = agent.generate_schedule(start_date, end_date)
        
        print(f"\nGenerated {result['total_tasks']} maintenance tasks")
        print(f"Equipment covered: {result['equipment_coverage']}")
        
        if result['conflicts']:
            print(f"\nConflicts: {len(result['conflicts'])}")
