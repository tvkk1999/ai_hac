import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any
from data_processor import DataProcessor

class RiskAssessment:
    """Advanced risk assessment and recommendation system"""
    
    def __init__(self, data_processor: DataProcessor):
        self.processor = data_processor
    
    def calculate_failure_probability(self, equipment_id: str, days_ahead: int = 30) -> Dict[str, Any]:
        """Calculate probability of failure in the next N days"""
        
        # Get equipment health
        health = self.processor.calculate_equipment_health_score(equipment_id)
        
        # Get failure history
        failures = self.processor.failure_data[
            self.processor.failure_data['equipment_id'] == equipment_id
        ]
        
        # Calculate failure rate (failures per year)
        if len(failures) > 0:
            days_observed = (datetime.now() - failures['date'].min()).days
            if days_observed > 0:
                failure_rate = len(failures) / (days_observed / 365.0)
            else:
                failure_rate = 0
        else:
            failure_rate = 0
        
        # Get days since last maintenance
        days_since_maintenance = health.get('days_since_maintenance', 90)
        
        # Calculate base probability using exponential decay model
        # P(failure) increases with time since maintenance and decreases with health
        health_factor = (100 - health['health_score']) / 100
        time_factor = min(days_since_maintenance / 90, 1.5)  # Cap at 1.5x
        
        base_probability = failure_rate * time_factor * (1 + health_factor)
        
        # Adjust for specific risk factors
        risk_multiplier = 1.0
        
        if health['health_score'] < 40:
            risk_multiplier *= 2.0
        elif health['health_score'] < 60:
            risk_multiplier *= 1.5
        
        if health.get('recent_failures', 0) > 0:
            risk_multiplier *= (1 + health['recent_failures'] * 0.3)
        
        # Calculate probability for next N days
        probability = min(base_probability * risk_multiplier * (days_ahead / 30), 0.95)
        
        # Calculate expected impact
        avg_downtime = failures['downtime_hours'].mean() if len(failures) > 0 else 8
        avg_production_loss = failures['production_loss_units'].mean() if len(failures) > 0 else 500
        
        expected_downtime = probability * avg_downtime
        expected_production_loss = probability * avg_production_loss
        
        # Risk score (0-100)
        risk_score = min(probability * 100 + health_factor * 50, 100)
        
        return {
            "equipment_id": equipment_id,
            "failure_probability": round(probability, 4),
            "failure_probability_pct": round(probability * 100, 2),
            "risk_score": round(risk_score, 2),
            "expected_downtime_hours": round(expected_downtime, 2),
            "expected_production_loss": int(expected_production_loss),
            "contributing_factors": {
                "health_score": health['health_score'],
                "days_since_maintenance": days_since_maintenance,
                "historical_failure_rate": round(failure_rate, 3),
                "recent_failures": health.get('recent_failures', 0)
            },
            "recommendation": self._get_risk_recommendation(probability, health['health_score'])
        }
    
    def _get_risk_recommendation(self, probability: float, health_score: float) -> str:
        """Get recommendation based on risk level"""
        if probability > 0.5 or health_score < 40:
            return "URGENT: Schedule immediate maintenance within 48 hours"
        elif probability > 0.3 or health_score < 60:
            return "HIGH PRIORITY: Schedule maintenance within 1 week"
        elif probability > 0.15 or health_score < 75:
            return "MODERATE: Schedule maintenance within 2 weeks"
        else:
            return "LOW RISK: Follow normal maintenance schedule"
    
    def assess_schedule_risk(self, schedule_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess overall risk of the maintenance schedule"""
        
        # Get all equipment
        all_equipment = self.processor.usage_data['equipment_id'].unique()
        scheduled_equipment = set([task['equipment_id'] for task in schedule_data['schedule']])
        unscheduled_equipment = set(all_equipment) - scheduled_equipment
        
        # Calculate risk for unscheduled equipment
        high_risk_unscheduled = []
        total_risk_score = 0
        
        for eq_id in unscheduled_equipment:
            risk = self.calculate_failure_probability(eq_id, days_ahead=30)
            total_risk_score += risk['risk_score']
            
            if risk['failure_probability'] > 0.2:
                health = self.processor.calculate_equipment_health_score(eq_id)
                eq_name = self.processor.usage_data[
                    self.processor.usage_data['equipment_id'] == eq_id
                ]['equipment_name'].iloc[0]
                
                high_risk_unscheduled.append({
                    "equipment_id": eq_id,
                    "equipment_name": eq_name,
                    "risk_score": risk['risk_score'],
                    "failure_probability": risk['failure_probability_pct'],
                    "health_score": health['health_score']
                })
        
        # Sort by risk
        high_risk_unscheduled.sort(key=lambda x: x['risk_score'], reverse=True)
        
        # Calculate schedule coverage
        coverage_pct = (len(scheduled_equipment) / len(all_equipment)) * 100
        
        # Overall assessment
        if len(high_risk_unscheduled) > 5:
            overall_risk = "HIGH"
            assessment = f"{len(high_risk_unscheduled)} high-risk equipment not scheduled"
        elif len(high_risk_unscheduled) > 0:
            overall_risk = "MODERATE"
            assessment = f"{len(high_risk_unscheduled)} high-risk equipment not scheduled"
        else:
            overall_risk = "LOW"
            assessment = "All high-risk equipment covered"
        
        return {
            "overall_risk_level": overall_risk,
            "assessment": assessment,
            "schedule_coverage_pct": round(coverage_pct, 2),
            "total_equipment": len(all_equipment),
            "scheduled_equipment": len(scheduled_equipment),
            "unscheduled_equipment": len(unscheduled_equipment),
            "high_risk_unscheduled": high_risk_unscheduled[:10],
            "average_unscheduled_risk": round(total_risk_score / max(len(unscheduled_equipment), 1), 2)
        }
    
    def generate_optimization_recommendations(self, 
                                             schedule_data: Dict[str, Any],
                                             risk_assessment: Dict[str, Any]) -> List[str]:
        """Generate specific recommendations for schedule optimization"""
        
        recommendations = []
        
        # Check coverage
        if risk_assessment['schedule_coverage_pct'] < 50:
            recommendations.append(
                f"⚠️ Low coverage: Only {risk_assessment['schedule_coverage_pct']:.1f}% of equipment scheduled. "
                "Consider extending schedule period or adding more resources."
            )
        
        # High-risk unscheduled equipment
        if len(risk_assessment['high_risk_unscheduled']) > 0:
            top_risk = risk_assessment['high_risk_unscheduled'][0]
            recommendations.append(
                f"🔴 URGENT: {top_risk['equipment_name']} ({top_risk['equipment_id']}) has "
                f"{top_risk['failure_probability']:.1f}% failure probability but is not scheduled. "
                f"Add to schedule immediately."
            )
        
        # Analyze task distribution
        df_schedule = pd.DataFrame(schedule_data['schedule'])
        if not df_schedule.empty:
            df_schedule['scheduled_date'] = pd.to_datetime(df_schedule['scheduled_date'])
            
            # Check for clustering
            date_counts = df_schedule.groupby('scheduled_date').size()
            if date_counts.max() > 5:
                max_date = date_counts.idxmax().strftime('%Y-%m-%d')
                recommendations.append(
                    f"⚡ Resource bottleneck: {date_counts.max()} tasks on {max_date}. "
                    "Consider redistributing to adjacent days."
                )
            
            # Check for gaps
            date_range = pd.date_range(
                df_schedule['scheduled_date'].min(),
                df_schedule['scheduled_date'].max()
            )
            scheduled_dates = set(df_schedule['scheduled_date'].dt.date)
            gaps = [d for d in date_range if d.date() not in scheduled_dates]
            
            if len(gaps) > len(date_range) * 0.5:
                recommendations.append(
                    f"📅 Schedule fragmentation: {len(gaps)} unused days in schedule period. "
                    "Consider consolidating tasks for better resource utilization."
                )
            
            # Check technician balance
            tech_counts = df_schedule['assigned_technician'].value_counts()
            if tech_counts.max() / tech_counts.min() > 3:
                overloaded = tech_counts.idxmax()
                underutilized = tech_counts.idxmin()
                recommendations.append(
                    f"👥 Unbalanced workload: {overloaded} has {tech_counts.max()} tasks vs "
                    f"{underutilized} with {tech_counts.min()} tasks. Review skill requirements."
                )
            
            # Priority distribution
            priority_counts = df_schedule['priority'].value_counts()
            if 'Critical' in priority_counts and priority_counts['Critical'] > 0:
                critical_dates = df_schedule[df_schedule['priority'] == 'Critical']['scheduled_date']
                days_to_critical = (critical_dates.min() - datetime.now()).days
                if days_to_critical > 7:
                    recommendations.append(
                        f"⏰ Critical tasks delayed: First critical task scheduled {days_to_critical} days out. "
                        "Review priority scheduling."
                    )
        
        # Production alignment
        if hasattr(self.processor, 'production_data') and self.processor.production_data is not None:
            prod_high_priority = self.processor.production_data[
                self.processor.production_data['production_priority'] == 'Rush Order'
            ]
            
            if not prod_high_priority.empty and not df_schedule.empty:
                rush_dates = set(pd.to_datetime(prod_high_priority['date']).dt.date)
                scheduled_dates = set(df_schedule['scheduled_date'].dt.date)
                conflicts = rush_dates.intersection(scheduled_dates)
                
                if conflicts:
                    recommendations.append(
                        f"🏭 Production conflict: {len(conflicts)} maintenance days overlap with rush orders. "
                        "Consider rescheduling to minimize production impact."
                    )
        
        # General best practices
        if len(recommendations) == 0:
            recommendations.extend([
                "✅ Schedule appears well-balanced with good coverage",
                "💡 Monitor high-vibration equipment for early warning signs",
                "📊 Continue tracking actual vs predicted maintenance needs",
                "🔧 Ensure spare parts availability for scheduled maintenance"
            ])
        else:
            # Add general recommendations
            recommendations.append(
                "💡 Review equipment health trends weekly to adjust schedule proactively"
            )
        
        return recommendations

if __name__ == "__main__":
    from data_processor import DataProcessor
    
    processor = DataProcessor()
    if processor.load_data():
        risk_assessment = RiskAssessment(processor)
        
        # Test risk calculation
        equipment_ids = processor.usage_data['equipment_id'].unique()[:3]
        for eq_id in equipment_ids:
            risk = risk_assessment.calculate_failure_probability(eq_id)
            print(f"\n{eq_id}: {risk['failure_probability_pct']}% failure probability")
            print(f"Recommendation: {risk['recommendation']}")
