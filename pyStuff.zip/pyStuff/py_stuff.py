def get_full_name(first_name: str, last_name: str, age: int):
    full_name: str = first_name.capitalize() + " " + last_name.capitalize() + "'s age is " + str(age)
    return full_name

print(get_full_name(first_name="Andu", last_name="Man", age=24))