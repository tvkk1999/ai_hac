from PIL import Image

# ASCII characters used to build the output text
ASCII_CHARS = ["@", "#", "S", "%", "?", "*", "+", ";", ":", ",", "."]

def resize_image(image, new_width=100):
    width, height = image.size
    ratio = height / width / 1.65
    new_height = int(new_width * ratio)
    return image.resize((new_width, new_height))

def grayify(image):
    return image.convert("L")

def pixels_to_ascii(image):
    pixels = image.getdata()
    characters = "".join([ASCII_CHARS[pixel // 25] for pixel in pixels])
    return characters

def image_to_ascii(path):
    try:
        image = Image.open(path)
    except:
        print(path, "not found.")
        return
    
    image = resize_image(image)
    image = grayify(image)
    new_image_data = pixels_to_ascii(image)
    pixel_count = len(new_image_data)
    ascii_image = "\n".join(
        [new_image_data[index:(index+image.width)] for index in range(0, pixel_count, image.width)]
    )
    
    with open("ascii_art.txt", "w") as f:
        f.write(ascii_image)
    print(ascii_image)

# Example usage
image_to_ascii("./imgs/ta.jpg")
