from fastapi import FastAPI
from enum import Enum

app = FastAPI()

class DeviceName(str, Enum):
    keyboard = "Keyboard"
    mouse = "Mouse"
    monitor = "Monitor"
    laptop = "Laptop"

@app.get("/")
async def root():
    return {"message": "Hello World!"}

@app.get("/items/{item_id}")
async def read_item(item_id: int):
    return {"item_id": item_id}

@app.get("/devices/{device_name}")
async def get_device(device_name: DeviceName):
    if device_name in DeviceName.keyboard + DeviceName.mouse:
        return {'name': device_name, 'type': 'input'}
    return {'name': device_name, 'type': 'non-input'}