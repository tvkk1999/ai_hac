from itertools import chain
from fastapi import FastAPI, HTTPException, Request, Form
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uuid
import time
import httpx
from starlette.exceptions import HTTPException as StarletteHTTPException

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# static files (css/js)
app.mount("/static", StaticFiles(directory="static"), name="static")

# in-memory store for demo (use DB in real app)
CHATS = {}  # chat_id -> {messages: [{role, text, ts}], modified_at}
username = "string1"

# DB retrieval utils
def get_chats_list():
    url = f"http://127.0.0.1:8000/users/{username}/chats"
    response = httpx.get(url)
    data = response.json()
    print(data)
    print("-"*100)
    print(data[0].keys())
    chat_list = [{"chat_id": c.get("id", ""), "title": c.get("title", "")} for c in data]
    print(chat_list)
    return chat_list

def get_messages_list(chat_id):
    url = f"http://127.0.0.1:8000/users/{username}/chats"
    response = httpx.get(url)
    data = response.json()
    print(data)
    chat_list = [{"chat_id": c["id"], "title":c["title"]} for c in data]
    print(chat_list)
    return chat_list

@app.get("/")
def home():
    url = "http://127.0.0.1:8000/chats"
    payload = {
        "username": username,
        "title": "New Chat"
    }
    response = httpx.post(url, json=payload)
    data = response.json()
    print(data)
    chat_id = data["id"]
    return RedirectResponse(url=f"/chat/{chat_id}")


@app.get("/chat/{chat_id}", response_class=HTMLResponse)
def get_chat(request: Request, chat_id: str):
    chat_list = get_chats_list()
    flag = False
    for c in chat_list:
        print(c)
        if chat_id == c["chat_id"]:
            flag = True
            break
    if flag:
        chat = CHATS.get(chat_id, {"messages": []})
        rendered = templates.get_template("partials/chats_list_snippet.html").render({"chat_list": chat_list})
        print(rendered)
        return templates.TemplateResponse("chat.html", {"request": request, "chat": chat, "chat_id": chat_id, "chats_list_rendered": rendered})
    raise HTTPException(404, "Not found")

@app.post("/chat/{chat_id}/message")
async def post_message(request: Request, chat_id: str, message: str = Form(...)):
    # store message
    chat = CHATS.setdefault(chat_id, {"messages": [], "modified_at": time.time()})
    chat["messages"].append({"role":"user", "text": message, "ts": time.time()})

    # simulate LLM processing (replace with real call)
    llm_reply = f"LLM reply to: {message}"

    # store bot reply
    chat["messages"].append({"role":"bot", "text": llm_reply, "ts": time.time()})
    chat["modified_at"] = time.time()
    
    print(chat)

    # OPTION A: return JSON (structured) and let client render
    # return JSONResponse({"status":"ok","reply":llm_reply, "user_message": message})

    # OPTION B: render a small HTML snippet server-side and return it (client injects into DOM)
    rendered = templates.get_template("partials/messages_snippet1.html").render({"messages": chat["messages"][-2:]})
    return JSONResponse({"status":"ok", "html": rendered})

@app.post("/chats/new")
async def new_chat():
    chat_id = str(uuid.uuid4())
    CHATS[chat_id] = {"messages": [], "modified_at": time.time()}
    # respond with url and optionally initial html for the new chat area
    return JSONResponse({"status":"ok", "chat_id": chat_id, "url": f"/chat/{chat_id}"})


@app.exception_handler(StarletteHTTPException)
async def custom_http_exception_handler(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 404:
        return JSONResponse(
            status_code=404,
            content={"message": "Route not found"}
        )
    return JSONResponse(
        status_code=exc.status_code,
        content={"message": exc.detail}
    )
