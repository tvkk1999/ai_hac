const sidebar = document.getElementById("sidebar");
const toggleSidebar = document.getElementById("toggleSidebar");
const messages = document.getElementById("messages");
const input = document.getElementById("input");
const sendBtn = document.getElementById("sendBtn");
const attachBtn = document.getElementById("attachBtn");
const fileInput = document.getElementById("fileInput");
const popupBtn = document.getElementById("popupBtn");
const popup = document.getElementById("popup");
const popupAdd = document.getElementById("popupAdd");
const popupCancel = document.getElementById("popupCancel");
const popupUrl = document.getElementById("popupUrl");
const popupText = document.getElementById("popupText");
const clearBtn = document.getElementById("clearBtn");

toggleSidebar.addEventListener("click", () => {
  // Toggle collapsed state on the sidebar element
  sidebar.classList.toggle("collapsed");
  // Also toggle a class on the root .app so the grid updates and the main area expands
  document.querySelector(".app").classList.toggle("sidebar-collapsed");
});

sendBtn.addEventListener("click", sendMessage);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

attachBtn.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  appendMessage(`📎 Attached: ${file.name}`, "user");
  // reset
  fileInput.value = "";
});

popupBtn.addEventListener("click", () => {
  popup.classList.toggle("open");
  if (popup.classList.contains("open")) {
    // position popup relative to input area (simple)
    // focus url
    popupUrl.focus();
  }
});

popupCancel.addEventListener("click", () => {
  popup.classList.remove("open");
  popupUrl.value = "";
  popupText.value = "";
});

popupAdd.addEventListener("click", () => {
  const url = popupUrl.value.trim();
  const txt = popupText.value.trim();
  if (url) appendMessage(`🔗 Link: ${url}\n${txt ? "\n" + txt : ""}`, "user");
  else if (txt) appendMessage(txt, "user");
  popup.classList.remove("open");
  popupUrl.value = "";
  popupText.value = "";
});

clearBtn.addEventListener("click", () => {
  messages.innerHTML =
    '<div class="msg bot">Hello! This is a ChatGPT-like UI prototype. Ask me anything.</div>';
});

function appendMessage(text, who = "user") {
  const el = document.createElement("div");
  el.className = "msg " + (who === "user" ? "user" : "bot");
  // preserve line breaks
  el.innerHTML = text.replace(/\n/g, "<br>");
  messages.appendChild(el);
  messages.scrollTop = messages.scrollHeight;
}

function sendMessage() {
  const txt = input.value.trim();
  if (!txt) return;
  appendMessage(txt, "user");
  input.value = "";

  // fake bot reply to mimic chatgpt feel
  setTimeout(() => {
    appendMessage("Thinking...", "bot");
    messages.scrollTop = messages.scrollHeight;
  }, 200);
  setTimeout(() => {
    // replace the last bot "Thinking..." message
    const botMsgs = Array.from(messages.querySelectorAll(".msg.bot"));
    const last = botMsgs[botMsgs.length - 1];
    if (last && last.textContent.trim() === "Thinking...") {
      last.innerHTML =
        "This is a simulated assistant reply to: <br><em>" +
        escapeHtml(txt) +
        "</em>";
    } else {
      appendMessage("This is a simulated assistant reply.", "bot");
    }
    messages.scrollTop = messages.scrollHeight;
  }, 800 + Math.random() * 300);
}

function escapeHtml(unsafe) {
  return unsafe.replace(/[&<>\"']/g, function (m) {
    return {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;",
    }[m];
  });
}

// small autosize for textarea
const ta = input;
function autosize() {
  ta.style.height = "auto";
  ta.style.height = ta.scrollHeight + "px";
}
ta.addEventListener("input", autosize);
autosize();
