import chainlit as cl
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
import os
from dotenv import load_dotenv
from database import get_db
import crud

load_dotenv()

# Initialize OpenAI
llm = ChatOpenAI(
    model="gpt-3.5-turbo",
    temperature=0.7,
    streaming=True,
    api_key=os.getenv("OPENAI_API_KEY")
)


@cl.on_chat_start
async def start():
    """Initialize chat session"""
    db = get_db()
    
    # Check if resuming existing conversation
    conversation_id = cl.user_session.get("conversation_id")
    
    if not conversation_id:
        # Create new conversation
        conversation = crud.create_conversation(db, user_id="default_user")
        conversation_id = conversation.id
        cl.user_session.set("conversation_id", conversation_id)
        
        await cl.Message(content="👋 Hello! I'm your AI assistant. How can I help you today?").send()
    else:
        # Load existing conversation
        messages = crud.get_messages(db, conversation_id)
        
        # Restore chat history in UI
        for msg in messages:
            await cl.Message(
                content=msg.content,
                author=msg.role
            ).send()
    
    # Initialize LangChain memory
    memory = ConversationBufferMemory(return_messages=True)
    
    # Load previous messages into memory
    messages = crud.get_messages(db, conversation_id)
    for msg in messages:
        if msg.role == "user":
            memory.chat_memory.add_user_message(msg.content)
        else:
            memory.chat_memory.add_ai_message(msg.content)
    
    # Create conversation chain
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful AI assistant. Provide clear, concise, and accurate responses."),
        MessagesPlaceholder(variable_name="history"),
        ("human", "{input}")
    ])
    
    conversation = ConversationChain(
        llm=llm,
        memory=memory,
        prompt=prompt,
        verbose=False
    )
    
    cl.user_session.set("conversation", conversation)
    cl.user_session.set("memory", memory)


@cl.on_message
async def main(message: cl.Message):
    """Handle incoming messages"""
    conversation = cl.user_session.get("conversation")
    conversation_id = cl.user_session.get("conversation_id")
    db = get_db()
    
    # Save user message to database
    crud.create_message(
        db=db,
        conversation_id=conversation_id,
        role="user",
        content=message.content
    )
    
    # Get response from LangChain with streaming
    msg = cl.Message(content="")
    await msg.send()
    
    # Stream the response
    response_content = ""
    async for chunk in conversation.astream({"input": message.content}):
        if "response" in chunk:
            token = chunk["response"]
            response_content += token
            await msg.stream_token(token)
    
    await msg.update()
    
    # Save assistant message to database
    crud.create_message(
        db=db,
        conversation_id=conversation_id,
        role="assistant",
        content=response_content
    )