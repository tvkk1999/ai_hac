import uuid
from sqlalchemy.orm import Session
from database import Conversation, Message
from datetime import datetime


def create_conversation(db: Session, user_id: str = "default_user"):
    """Create a new conversation"""
    conversation = Conversation(
        id=str(uuid.uuid4()),
        user_id=user_id,
        title="New Chat"
    )
    db.add(conversation)
    db.commit()
    db.refresh(conversation)
    return conversation


def get_conversation(db: Session, conversation_id: str):
    """Get a conversation by ID"""
    return db.query(Conversation).filter(Conversation.id == conversation_id).first()


def get_conversations(db: Session, user_id: str = "default_user", limit: int = 20):
    """Get all conversations for a user"""
    return db.query(Conversation).filter(
        Conversation.user_id == user_id
    ).order_by(Conversation.updated_at.desc()).limit(limit).all()


def create_message(db: Session, conversation_id: str, role: str, content: str):
    """Create a new message"""
    message = Message(
        id=str(uuid.uuid4()),
        conversation_id=conversation_id,
        role=role,
        content=content
    )
    db.add(message)
    
    # Update conversation timestamp
    conversation = get_conversation(db, conversation_id)
    if conversation:
        conversation.updated_at = datetime.utcnow()
        # Update title based on first message
        if role == "user" and conversation.title == "New Chat":
            conversation.title = content[:50] + ("..." if len(content) > 50 else "")
    
    db.commit()
    db.refresh(message)
    return message


def get_messages(db: Session, conversation_id: str):
    """Get all messages for a conversation"""
    return db.query(Message).filter(
        Message.conversation_id == conversation_id
    ).order_by(Message.created_at).all()


def delete_conversation(db: Session, conversation_id: str):
    """Delete a conversation and its messages"""
    conversation = get_conversation(db, conversation_id)
    if conversation:
        db.delete(conversation)
        db.commit()
        return True
    return False