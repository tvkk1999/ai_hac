from langchain_openai import ChatOpenAI 
import os 
import httpx 
client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model = "azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-psJWnUf2HGUE90ew2RGCyA",
    http_client = client
)
result = llm.invoke("Hi")
print(result)
print("-"*100)
print(result.content)