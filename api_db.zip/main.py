from typing import Optional, List
from fastapi import FastAPI, HTTPException, status, Query
from pydantic import BaseModel, Field
from datetime import datetime
import motor.motor_asyncio
from bson import ObjectId
from passlib.context import CryptContext
from passlib.hash import argon2

# ---------- Helpers ----------
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_password_hash(password: str) -> str:
    return argon2.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return argon2.verify(plain, hashed)

# Convert Mongo documents to JSON-serializable dicts
def doc_to_dict(doc: dict) -> dict:
    if not doc:
        return {}
    doc = dict(doc)
    if "_id" in doc:
        doc["id"] = str(doc.pop("_id"))
    if "chat_id" in doc and isinstance(doc["chat_id"], ObjectId):
        doc["chat_id"] = str(doc["chat_id"])
    return doc

# ---------- Pydantic Models ----------
class UserCreate(BaseModel):
    username: str = Field(..., min_length=3)
    password: str = Field(..., min_length=6)

class UserOut(BaseModel):
    username: str
    created_at: datetime

class UserUpdate(BaseModel):
    password: Optional[str] = Field(None, min_length=6)

class ChatCreate(BaseModel):
    username: str
    title: Optional[str] = "Untitled"

class ChatOut(BaseModel):
    id: str
    username: str
    title: str
    created_at: datetime
    updated_at: Optional[datetime]

class ChatUpdate(BaseModel):
    title: Optional[str]

class MessageCreate(BaseModel):
    chat_id: str
    role: str
    content: str

class MessageOut(BaseModel):
    id: str
    chat_id: str
    role: str
    content: str
    created_at: datetime

class MessageUpdate(BaseModel):
    content: Optional[str]

# ---------- App and DB setup ----------
app = FastAPI(title="FastAPI MongoDB CRUD Example")

# Change the URI if needed (auth, remote server, etc.)
MONGO_URI = "mongodb://localhost:27017"
client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URI)
db = client['chat_db']
users_col = db['users']
chats_col = db['chats']
messages_col = db['messages']

# Ensure indexes (run at startup)
@app.on_event("startup")
async def startup_indexes():
    await users_col.create_index("username", unique=True)
    await chats_col.create_index("username")
    await messages_col.create_index("chat_id")

# ---------- Users endpoints ----------
@app.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(user: UserCreate):
    hashed = get_password_hash(user.password)
    now = datetime.utcnow()
    doc = {"username": user.username, "password": hashed, "created_at": now}
    try:
        await users_col.insert_one(doc)
    except Exception as e:
        raise HTTPException(status_code=400, detail="Username already exists or invalid data")
    return {"username": user.username, "created_at": now}

@app.get("/users/{username}", response_model=UserOut)
async def get_user(username: str):
    doc = await users_col.find_one({"username": username}, {"password": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="User not found")
    return {"username": doc["username"], "created_at": doc["created_at"]}

@app.put("/users/{username}", response_model=UserOut)
async def update_user(username: str, data: UserUpdate):
    update = {}
    if data.password:
        update["password"] = get_password_hash(data.password)
    if not update:
        raise HTTPException(status_code=400, detail="No updatable fields provided")
    result = await users_col.update_one({"username": username}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    doc = await users_col.find_one({"username": username}, {"password": 0})
    return {"username": doc["username"], "created_at": doc["created_at"]}

@app.delete("/users/{username}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(username: str):
    result = await users_col.delete_one({"username": username})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    # Optionally delete related chats/messages
    await chats_col.delete_many({"username": username})
    return None

# ---------- Chats endpoints ----------
@app.post("/chats", response_model=ChatOut, status_code=status.HTTP_201_CREATED)
async def create_chat(chat: ChatCreate):
    # Ensure user exists
    user = await users_col.find_one({"username": chat.username})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    now = datetime.utcnow()
    doc = {"username": chat.username, "title": chat.title, "created_at": now, "updated_at": None}
    res = await chats_col.insert_one(doc)
    doc = await chats_col.find_one({"_id": res.inserted_id})
    return doc_to_dict(doc)

@app.get("/chats/{chat_id}", response_model=ChatOut)
async def get_chat(chat_id: str):
    try:
        oid = PyObjectId.validate(chat_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid chat_id")
    doc = await chats_col.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Chat not found")
    return doc_to_dict(doc)

@app.get("/users/{username}/chats", response_model=List[ChatOut])
async def list_user_chats(username: str, limit: int = Query(50, ge=1, le=100), skip: int = 0):
    cursor = chats_col.find({"username": username}).sort("created_at", -1).skip(skip).limit(limit)
    docs = [doc_to_dict(d) async for d in cursor]
    return docs

@app.put("/chats/{chat_id}", response_model=ChatOut)
async def update_chat(chat_id: str, data: ChatUpdate):
    try:
        oid = PyObjectId.validate(chat_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid chat_id")
    update = {}
    if data.title is not None:
        update["title"] = data.title
    if not update:
        raise HTTPException(status_code=400, detail="No updatable fields provided")
    update["updated_at"] = datetime.utcnow()
    result = await chats_col.update_one({"_id": oid}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Chat not found")
    doc = await chats_col.find_one({"_id": oid})
    return doc_to_dict(doc)

@app.delete("/chats/{chat_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_chat(chat_id: str):
    try:
        oid = PyObjectId.validate(chat_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid chat_id")
    res = await chats_col.delete_one({"_id": oid})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Chat not found")
    # Optionally delete messages for this chat
    await messages_col.delete_many({"chat_id": oid})
    return None

# ---------- Messages endpoints ----------
@app.post("/messages", response_model=MessageOut, status_code=status.HTTP_201_CREATED)
async def create_message(msg: MessageCreate):
    try:
        chat_oid = PyObjectId.validate(msg.chat_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid chat_id")
    # Ensure chat exists
    chat = await chats_col.find_one({"_id": chat_oid})
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    now = datetime.utcnow()
    doc = {"chat_id": chat_oid, "role": msg.role, "content": msg.content, "created_at": now}
    res = await messages_col.insert_one(doc)
    doc = await messages_col.find_one({"_id": res.inserted_id})
    return doc_to_dict(doc)

@app.get("/messages/{message_id}", response_model=MessageOut)
async def get_message(message_id: str):
    try:
        oid = PyObjectId.validate(message_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid message_id")
    doc = await messages_col.find_one({"_id": oid})
    if not doc:
        raise HTTPException(status_code=404, detail="Message not found")
    return doc_to_dict(doc)

@app.get("/chats/{chat_id}/messages", response_model=List[MessageOut])
async def list_chat_messages(chat_id: str, limit: int = Query(100, ge=1, le=1000), skip: int = 0):
    try:
        chat_oid = PyObjectId.validate(chat_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid chat_id")
    cursor = messages_col.find({"chat_id": chat_oid}).sort("created_at", 1).skip(skip).limit(limit)
    docs = [doc_to_dict(d) async for d in cursor]
    return docs

@app.put("/messages/{message_id}", response_model=MessageOut)
async def update_message(message_id: str, data: MessageUpdate):
    try:
        oid = PyObjectId.validate(message_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid message_id")
    update = {}
    if data.content is not None:
        update["content"] = data.content
    if not update:
        raise HTTPException(status_code=400, detail="No updatable fields provided")
    result = await messages_col.update_one({"_id": oid}, {"$set": update})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Message not found")
    doc = await messages_col.find_one({"_id": oid})
    return doc_to_dict(doc)

@app.delete("/messages/{message_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_message(message_id: str):
    try:
        oid = PyObjectId.validate(message_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid message_id")
    res = await messages_col.delete_one({"_id": oid})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Message not found")
    return None

# ---------- Small utility endpoint to health check ----------
@app.get("/health")
async def health():
    return {"status": "ok"}
