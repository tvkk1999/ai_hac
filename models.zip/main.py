# main.py
import uuid
from typing import List, Optional
from datetime import datetime

from fastapi import FastAPI, HTTPException, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy import (
    Column, String, Text, TIMESTAMP, ForeignKey, func, select, update, delete
)
from sqlalchemy.dialects.postgresql import UUID as PGUUID
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import declarative_base, sessionmaker
from passlib.context import CryptContext

# ---------- CONFIG ----------
DATABASE_URL = "postgresql+asyncpg://postgres:mkukkkjk@localhost:5432/ai_chat"
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

# ---------- DB / ORM ----------
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    username = Column(String, primary_key=True, index=True)
    password = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())

class Chat(Base):
    __tablename__ = "chats"
    chat_id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String, ForeignKey("users.username"), nullable=False, index=True)
    title = Column(Text)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
    modified_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

class Message(Base):
    __tablename__ = "messages"
    message_id = Column(PGUUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    chat_id = Column(PGUUID(as_uuid=True), ForeignKey("chats.chat_id"), nullable=False, index=True)
    role = Column(String, nullable=False)  # 'user' | 'ai'
    content = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())

engine = create_async_engine(DATABASE_URL, echo=False, future=True)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

# ---------- Pydantic Schemas ----------
class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=6)

class UserRead(BaseModel):
    username: str
    created_at: datetime

    class Config:
        orm_mode = True

class ChatCreate(BaseModel):
    username: str
    title: Optional[str] = None

class ChatRead(BaseModel):
    chat_id: uuid.UUID
    username: str
    title: Optional[str]
    created_at: datetime
    modified_at: datetime

    class Config:
        orm_mode = True

class MessageCreate(BaseModel):
    chat_id: uuid.UUID
    role: str = Field(..., pattern="^(user|ai)$")
    content: str = Field(..., min_length=1)

class MessageRead(BaseModel):
    message_id: uuid.UUID
    chat_id: uuid.UUID
    role: str
    content: str
    created_at: datetime

    class Config:
        orm_mode = True

# ---------- Dependency ----------
async def get_session() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        yield session

# ---------- Utility ----------
def hash_password(password: str) -> str:
    return pwd_ctx.hash(password)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_ctx.verify(plain, hashed)

# ---------- App ----------
app = FastAPI(title="Chat PoC API")

# ---------- User Endpoints ----------
@app.post("/users", response_model=UserRead, status_code=status.HTTP_201_CREATED)
async def create_user(payload: UserCreate, session: AsyncSession = Depends(get_session)):
    # check exists
    q = await session.execute(select(User).where(User.username == payload.username))
    if q.scalars().first():
        raise HTTPException(status_code=400, detail="Username already exists")
    user = User(username=payload.username, password=hash_password(payload.password))
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user

@app.get("/users/{username}", response_model=UserRead)
async def read_user(username: str, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(User).where(User.username == username))
    user = q.scalars().first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.delete("/users/{username}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(username: str, session: AsyncSession = Depends(get_session)):
    # Note: cascade/foreign constraints not handled here - implement per your needs
    res = await session.execute(delete(User).where(User.username == username))
    await session.commit()
    if res.rowcount == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return

# ---------- Chat Endpoints ----------
@app.post("/chats", response_model=ChatRead, status_code=status.HTTP_201_CREATED)
async def create_chat(payload: ChatCreate, session: AsyncSession = Depends(get_session)):
    # ensure user exists
    q = await session.execute(select(User).where(User.username == payload.username))
    if not q.scalars().first():
        raise HTTPException(status_code=404, detail="User not found")
    chat = Chat(username=payload.username, title=payload.title)
    session.add(chat)
    await session.commit()
    await session.refresh(chat)
    return chat

@app.get("/chats/{chat_id}", response_model=ChatRead)
async def get_chat(chat_id: uuid.UUID, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Chat).where(Chat.chat_id == chat_id))
    chat = q.scalars().first()
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    return chat

@app.get("/users/{username}/chats", response_model=List[ChatRead])
async def list_user_chats(username: str, session: AsyncSession = Depends(get_session), limit: int = 50):
    q = await session.execute(
        select(Chat).where(Chat.username == username).order_by(Chat.modified_at.desc()).limit(limit)
    )
    return q.scalars().all()

@app.patch("/chats/{chat_id}", response_model=ChatRead)
async def update_chat(chat_id: uuid.UUID, title: Optional[str] = None, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Chat).where(Chat.chat_id == chat_id))
    chat = q.scalars().first()
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    if title is not None:
        chat.title = title
    session.add(chat)
    await session.commit()
    await session.refresh(chat)
    return chat

@app.delete("/chats/{chat_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_chat(chat_id: uuid.UUID, session: AsyncSession = Depends(get_session)):
    res = await session.execute(delete(Chat).where(Chat.chat_id == chat_id))
    await session.commit()
    if res.rowcount == 0:
        raise HTTPException(status_code=404, detail="Chat not found")
    return

# ---------- Message Endpoints ----------
@app.post("/messages", response_model=MessageRead, status_code=status.HTTP_201_CREATED)
async def create_message(payload: MessageCreate, session: AsyncSession = Depends(get_session)):
    """
    Insert a message and update chats.modified_at in the same transaction.
    """
    # ensure chat exists (and user too if you need)
    q = await session.execute(select(Chat).where(Chat.chat_id == payload.chat_id))
    chat = q.scalars().first()
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")

    async with session.begin():  # transaction scope
        msg = Message(chat_id=payload.chat_id, role=payload.role, content=payload.content)
        session.add(msg)
        # update modified_at server-side
        await session.execute(
            update(Chat).where(Chat.chat_id == payload.chat_id).values(modified_at=func.now())
        )
    # after commit we can refresh the message
    # find the inserted message (message_id defaults were generated server-side)
    # But since msg is added we can refresh
    await session.refresh(msg)
    return msg

@app.get("/chats/{chat_id}/messages", response_model=List[MessageRead])
async def list_messages(chat_id: uuid.UUID, session: AsyncSession = Depends(get_session), limit: int = 100, before: Optional[datetime] = None):
    q = select(Message).where(Message.chat_id == chat_id)
    if before:
        q = q.where(Message.created_at < before)
    q = q.order_by(Message.created_at).limit(limit)
    res = await session.execute(q)
    return res.scalars().all()

@app.get("/messages/{message_id}", response_model=MessageRead)
async def get_message(message_id: uuid.UUID, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Message).where(Message.message_id == message_id))
    msg = q.scalars().first()
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")
    return msg

@app.patch("/messages/{message_id}", response_model=MessageRead)
async def update_message(message_id: uuid.UUID, content: str, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Message).where(Message.message_id == message_id))
    msg = q.scalars().first()
    if not msg:
        raise HTTPException(status_code=404, detail="Message not found")
    msg.content = content
    session.add(msg)
    await session.commit()
    await session.refresh(msg)
    return msg

@app.delete("/messages/{message_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_message(message_id: uuid.UUID, session: AsyncSession = Depends(get_session)):
    res = await session.execute(delete(Message).where(Message.message_id == message_id))
    await session.commit()
    if res.rowcount == 0:
        raise HTTPException(status_code=404, detail="Message not found")
    return
