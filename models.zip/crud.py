# crud.py - transactional insert + update
import uuid
from sqlalchemy import update
from sqlalchemy.exc import SQLAlchemyError
from models import Message, Chat
from db import AsyncSessionLocal

async def add_message_and_touch_chat(chat_id: uuid.UUID, role: str, content: str):
    async with AsyncSessionLocal() as session:
        # session.begin() returns an async context manager that commits on exit or rollbacks on exception
        async with session.begin():
            # 1) insert message (Message.message_id defaults to uuid.uuid4)
            msg = Message(chat_id=chat_id, role=role, content=content)
            session.add(msg)

            # 2) update chats.modified_at to NOW()
            # Use SQL expression so DB sets timestamp (server side)
            await session.execute(
                update(Chat)
                .where(Chat.chat_id == chat_id)
                .values(modified_at=func.now())
            )
        # commit happens here if no exception
        return msg.message_id
